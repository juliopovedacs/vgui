//******************************************************************************
// Copyright (C) 2016-2018 University of Oklahoma Board of Trustees.
//******************************************************************************
// Last modified: Tue Feb  9 20:33:16 2016 by Chris Weaver
//******************************************************************************
// Major Modification History:
//
// 20160209 [weaver]:	Original file (for CS 4053/5053 homeworks).
// 20180123 [weaver]:	Modified for use in CS 3053 team projects.
//
//******************************************************************************
// Notes:
//
//******************************************************************************

package edu.ou.cs.hci.stages;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

//******************************************************************************

/**
 * The <CODE>Stage1</CODE> class.<P>
 *
 * @author  Chris Weaver
 * @version %I%, %G%
 */
public final class Stage1
{
	//**********************************************************************
	// Public Class Members
	//**********************************************************************
	
	/**
	 * Scenarios names file location
	 */
	public static final String SCENARIOS_TITLES_FILE = "resources/scenarios/titles.txt";
	
	/**
	 * Scenarios descriptions file location
	 */
	public static final String SCENARIOS_DESCRIPTIONS_FILE = "resources/scenarios/descriptions.txt";
	
	/**
	 * Scenarios titles ArrayList
	 */
	public static ArrayList<String> scenariosTitles;
	
	/**
	 * Scenarios descriptions ArrayList
	 */
	public static ArrayList<String> scenariosDescriptions;
	
	//**********************************************************************
	// Private Members
	//**********************************************************************

	
	
	//**********************************************************************
	// Main
	//**********************************************************************

	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args)
	{
		// Main frame
		
		// Create Main Frame
		JFrame frame = new JFrame("Stage 1");
		
		// Creates GamesDisplayPanel and UserDisplayPanel
		JPanel centerMainPanel = new GamesDisplayPanel();
		JPanel leftUserPanel = new UserDisplayPanel();

		// Sets Main Frame´s bounds and layout
		frame.setBounds(50, 50, 600, 600);
		frame.getContentPane().setLayout(new BorderLayout());
		
		// Adds GamesDisplayPanel and UserDisplayPanel to Main Frame
		frame.getContentPane().add(centerMainPanel, BorderLayout.CENTER);
		frame.getContentPane().add(leftUserPanel, BorderLayout.WEST);
			
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		frame.addWindowListener(new WindowAdapter() {public void windowClosing(WindowEvent e) {System.exit(0);}});
		
		
		// Personas and Scenarios Frame
		
		// Create Scenarios Frame
		JFrame scenariosFrame = new JFrame("Scenarios");
		
		// Scenarios Panel
		JPanel scenariosPanel = new ScenariosPanel();
		
		// Scenarios Frame settings
		scenariosFrame.setBounds(50, 50, 700, 300);
		scenariosFrame.getContentPane().setLayout(new BorderLayout());
		
		// Scenarios Panel added to Scenarios Frame
		scenariosFrame.getContentPane().add(scenariosPanel, BorderLayout.CENTER);
		
		scenariosFrame.setVisible(true);
		scenariosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}

	//**********************************************************************
	// Private Inner Classes
	//**********************************************************************
	
	/**
	 * SearchSortPanel
	 */
	private static final class SearchSortPanel extends JPanel
	{
		/**
		 * SearchSortPanel constructor
		 */
		public SearchSortPanel()
		{
			// Creates search field
			JTextField searchField = new JTextField("Search", 16);
			
			// Creates String array of sort by options
			String[] sortByOptions = {
				"Sort By:",
				"Title (A-Z)",
				"Title (Z-A)",
				"Platform",
				"Release Date"
			};
			
			// Creates a  combo box
			JComboBox sortByBox = new JComboBox(sortByOptions);
			
			// Sets layout
			setLayout(new BorderLayout());
			
			// Adds search text field and sort by combo box
			add(searchField, BorderLayout.WEST);
			add(sortByBox, BorderLayout.EAST);
		}
	}

	/**
	 * GamesDisplayPanel
	 */
	private static final class GamesDisplayPanel extends JPanel
	{
		/**
		 * GamesDisplayPanel constructor
		 */
		public GamesDisplayPanel()
		{
			// Creates SearchSortPanel
			JPanel 	searchSortPanel = new SearchSortPanel();
			
			// Sets layout
			setLayout(new BorderLayout());
			
			// Creates display panel
			JPanel display = new JPanel();
			display.setLayout(new GridLayout(12,3));
			
			// Adds games
			for (int i = 0; i < 12; i++) 
			{
				for (int j = 0; j < 3; j++) 
				{
					JButton btn = new JButton("Game " + i + j);
					btn.setPreferredSize(new Dimension(100, 100));
					display.add(btn);
				}
			}
			
			// Adds scroll pane
			JScrollPane scrollPane = new JScrollPane(display, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			
			// Adds searchSortPanel and scrollPane to GamesDisplayPanel
			add(searchSortPanel, BorderLayout.NORTH);
			add(scrollPane, BorderLayout.CENTER);
		}
	}
	
	/**
	 * UserDisplayPanel
	 */
	private static final class UserDisplayPanel extends JPanel
	{
		/**
		 * UserDisplayPanel constructor
		 */
		public UserDisplayPanel() 
		{
			// Sets layout
			setLayout(new GridLayout(20, 1));
			
			// Adds UI elements
			add(new JLabel("User Profile"));
			add(new JButton("Home"));
			add(new JButton("Featured Games"));
			add(new JButton("News and Events"));
			add(new JButton("My Games"));
			add(new JButton("My Favorites"));
			add(new JButton("My Wishlist"));
			add(new JButton("Recently Played"));
			add(new JButton("Most Played"));
			add(new JButton("Least Played"));
			add(new JButton("Never Played"));
			add(new JButton("Shuffle"));
		}
	}
	
	/**
	 * Scenarios Panel
	 */
	private static final class ScenariosPanel extends JPanel
	{
		/**
		 * ScenariosPanel constructor
		 */
		public ScenariosPanel()
		{
			// Sets panel layout
			setLayout(new BorderLayout());
						
			// Creates an instance of resources
			Resources resources = new Resources();
			
			// Initializes ArrayList that will store scenarios titles
			scenariosTitles = new ArrayList<>();
			
			// InitializesArrayList that will store scenarios descriptions
			scenariosDescriptions = new ArrayList<>();
			
			// Variable that will determine if files were read
			boolean filesRead = false;
			
			try
			{
				// Read Scenarios titles
				scenariosTitles = resources.getLines(SCENARIOS_TITLES_FILE);
				
				// Read Scenarios descriptions
				scenariosDescriptions = resources.getLines(SCENARIOS_DESCRIPTIONS_FILE);
				
				filesRead = true;
			}
			catch (Exception e)
			{
				// Error reading the files
				add(new JLabel("Mm, it seems as if there is an error reading your files. Are they written properly?"), BorderLayout.NORTH);
			}
			
			if(filesRead)
			{
				// Files were read
				
				if(scenariosTitles.size() > 0)
				{
					// There are scenarios
					
					// Model that will have the list´s data
					DefaultListModel<String> listModel = new DefaultListModel<>();
					
					// For every row in the SCENARIOS_NAMES_FILE add an element to the model
					for(int i = 0; i < scenariosTitles.size(); i++)
					{
						listModel.addElement(scenariosTitles.get(i));
					}
								
					// Creates scenarios list
					JList<String> scenariosList = new JList<>(listModel);
					
					// Single-selection JList of scenario titles
					scenariosList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
								
					// Creates scenarios descriptions text area
					JTextArea scenariosDescriptionsTextArea = new JTextArea();
					
					// Non-editable text area
					scenariosDescriptionsTextArea.setEditable(false);
					scenariosDescriptionsTextArea.setLineWrap(true);
					scenariosDescriptionsTextArea.setWrapStyleWord(true);
					
					// Creates a ListSelectionListener to update text area when a different scenario is selected
					scenariosList.addListSelectionListener(new ListSelectionListener() {
						public void valueChanged(ListSelectionEvent e)
						{
							int scenarioIndex = scenariosList.getSelectedIndex();
							scenariosDescriptionsTextArea.setText(scenariosDescriptions.get(scenarioIndex));
						}
					});
					
					// The first scenario is selected when the app starts
					scenariosList.setSelectedIndex(0);
						
					// Adds an instructions label to the panel
					add(new JLabel("Hi, to see a scenario description, click on a title:"), BorderLayout.NORTH);
					
					// Adds the scenarios list to the panel
					add(scenariosList, BorderLayout.WEST);
					
					// Adds the scenarios descriptions text area to the panel
					add(scenariosDescriptionsTextArea, BorderLayout.CENTER);
					
					// Adds a footer label to the panel
					add(new JLabel("By CGL"), BorderLayout.SOUTH);
				}
				else
				{
					// There are no scenarios
					
					// Adds an informative text to the panel
					add(new JLabel("Hi! There are no scenarios. What could have happened with them?"), BorderLayout.NORTH);
				}
			}
		}
	}
}

//******************************************************************************
