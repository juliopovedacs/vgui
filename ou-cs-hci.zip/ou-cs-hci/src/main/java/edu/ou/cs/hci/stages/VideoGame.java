package edu.ou.cs.hci.stages;

/**
 * Class that represents a Video Game
 */
public class VideoGame 
{
	//------------------------------------------------------------
	// Attributes
	//------------------------------------------------------------
	
	/**
	 * Video game name
	 */
	private String name;
	
	/**
	 * Video game developer
	 */
	private String developer;
	
	/**
	 * Video game publisher
	 */
	private String publisher;
	
	/**
	 * Video game year in which it was released
	 */
	private String yearReleased;
	
	/**
	 * Video game genre
	 */
	private String genre;
	
	/**
	 * Video game platforms
	 */
	private String platforms;
	
	/**
	 * Video game image
	 */
	private String image;
	
	/**
	 * User name of the video game
	 */
	private String userName;
	
	/**
	 * Library in which the video game has been put into by its user
	 */
	private String library;
	
	/**
	 * Video game rating
	 */
	private String rating;
	
	/**
	 * Video game summary
	 */
	private String summary;
	
	/**
	 * Video game reviews
	 */
	private String reviews;
	
	//------------------------------------------------------------
	// Constructor
	//------------------------------------------------------------
	
	/**
	 * Constructs a video game
	 * @param pName - Video game´s name
	 * @param pDeveloper - Video game´s developer
	 * @param pPublisher - Video game´s publisher
	 * @param pYearReleased - Video game´s year in which it was released
	 * @param pGenre - Video game´s genre
	 * @param pPlatforms - Video game´s platforms
	 * @param pImage - Video game´s image
	 * @param pLibrary - Video game´s library in which it has been put into by the user
	 * @param pRating - Video game´s rating
	 * @param pSummary - Video game´s summary
	 * @param pReviews - Video game´s reviews
	 */
	public VideoGame(String pName, String pDeveloper, String pPublisher, String pYearReleased, String pGenre, String pPlatforms, String pImage, String pLibrary, String pRating, String pSummary, String pReviews)
	{
		name = pName;
		developer = pDeveloper;
		publisher = pPublisher;
		yearReleased = pYearReleased;
		genre = pGenre;
		platforms = pPlatforms;
		image = pImage;
		library = pLibrary;
		rating = pRating;
		summary = pSummary;
		reviews = pReviews;
	}
	
	//------------------------------------------------------------
	// Methods
	//------------------------------------------------------------
	
	/**
	 * Returns video game´s name
	 * @return name
	 */
	public String getName()
	{
		return name;
	}
	
	/**
	 * Sets video game´s name to pName
	 * @param pName - New video game´s name
	 */
	public void setName(String pName)
	{
		name = pName;
	}
	
	/**
	 * Returns video game´s developer
	 * @return developer
	 */
	public String getDeveloper()
	{
		return developer;
	}
	
	/**
	 * Sets video game´s developer to pDeveloper
	 * @param pDeveloper - New video game´s developer
	 */
	public void setDeveloper(String pDeveloper)
	{
		developer = pDeveloper;
	}
	
	/**
	 * Returns video game´s publisher
	 * @return publisher
	 */
	public String getPublisher()
	{
		return publisher;
	}
	
	/**
	 * Sets video game´s publisher to pPublisher
	 * @param pPublisher - New video game´s publisher
	 */
	public void setPublisher(String pPublisher)
	{
		publisher = pPublisher;
	}
	
	/**
	 * Returns video game´s year released
	 * @return yearReleased
	 */
	public String getYearReleased()
	{
		return yearReleased;
	}
	
	/**
	 * Sets video game´s year released to pYearReleased
	 * @param pYearReleased - Video game´s new year released
	 */
	public void setYearReleased(String pYearReleased)
	{
		yearReleased = pYearReleased;
	}
	
	/**
	 * Returns video game´s genre
	 * @return genre
	 */
	public String getGenre()
	{
		return genre;
	}
	
	/**
	 * Sets video game´s genre to pGenre
	 * @param pGenre - New video game´s genre
	 */
	public void setGenre(String pGenre)
	{
		genre = pGenre;
	}
	
	/**
	 * Returns video game´s platforms
	 * @return platforms
	 */
	public String getPlatforms()
	{
		return platforms;
	}
	
	/**
	 * Sets video game´s platforms to pPlatforms
	 * @param pPlatforms - Video game´s new platforms
	 */
	public void setPlatforms(String pPlatforms)
	{
		platforms = pPlatforms;
	}
	
	/**
	 * Returns video game´s image
	 * @return image
	 */
	public String getImage()
	{
		return image;
	}
	
	/**
	 * Sets video game´s image to pImage
	 * @param pImage - New video game´s image
	 */
	public void setImage(String pImage)
	{
		image = pImage;
	}
	
	/**
	 * Return video game´s library
	 * @return library
	 */
	public String getLibrary()
	{
		return library;
	}
	
	/**
	 * Sets video game´s library to pLibrary
	 * @param pLibrary - New video game´s library
	 */
	public void setLibrary(String pLibrary)
	{
		library = pLibrary;
	}
	
	/**
	 * Returns video game´s rating
	 * @return rating
	 */
	public String getRating()
	{
		return rating;
	}
	
	/**
	 * Sets video game´s rating to pRating
	 * @param pRating - Video game´s rating
	 */
	public void setRating(String pRating)
	{
		rating = pRating;
	}
	
	/**
	 * Returns video game´s summary
	 * @return summary
	 */
	public String getSummary()
	{
		return summary;
	}
	
	/**
	 * Sets video game´s summary to pSummary
	 * @param pSummary - New video game´s summary
	 */
	public void setSummary(String pSummary)
	{
		summary = pSummary;
	}
	
	/**
	 * Return video game´s reviews
	 * @return reviews
	 */
	public String getReviews()
	{
		return reviews;
	}
	
	/**
	 * Sets video game´s reviews to pReviews
	 * @param pReviews - New video game´s reviews
	 */
	public void setReviews(String pReviews)
	{
		reviews = pReviews;
	}
	
	/**
	 * Adds pReviews to review
	 * @param pReview - New video game´s review
	 */
	public void addReview(String pReview)
	{
		reviews += " - " + pReview;
	}
}
