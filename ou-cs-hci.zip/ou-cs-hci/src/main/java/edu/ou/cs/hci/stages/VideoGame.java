package edu.ou.cs.hci.stages;

/**
 * Class that represents a Video Game
 */
public class VideoGame 
{
	//------------------------------------------------------------
	// Attributes
	//------------------------------------------------------------
	
	/**
	 * Video game name
	 */
	private String name;
	
	/**
	 * Video game developer
	 */
	private String developer;
	
	/**
	 * Video game publisher
	 */
	private String publisher;
	
	/**
	 * Video game year in which it was released
	 */
	private String yearReleased;
	
	/**
	 * Video game genre
	 */
	private String genre;
	
	/**
	 * Video game platform
	 */
	private String platform;
	
	/**
	 * Video game image
	 */
	private String image;
	
	/**
	 * User name of the video game
	 */
	private String userName;
	
	/**
	 * Categories in which the video game has been put into by its user
	 */
	private String userList;
	
	/**
	 * Video game rating
	 */
	private String rating;
	
	/**
	 * Video game summary
	 */
	private String summary;
	
	//------------------------------------------------------------
	// Constructor
	//------------------------------------------------------------
	
	/**
	 * Constructs a video game
	 * @param pName - Video game´s name
	 * @param pDeveloper - Video game´s developer
	 * @param pPublisher - Video game´s publisher
	 * @param pYearReleased - Video game´s year in which it was released
	 * @param pGenre - Video game´s genre
	 * @param pPlatform - Video game´s platform
	 * @param pImage - Video game´s image
	 * @param pUserList - Video game´s categories in which it has been put into by the user
	 * @param pRating - Video game´s rating
	 * @param pSummary - Video game´s summary
	 */
	public VideoGame(String pName, String pDeveloper, String pPublisher, String pYearReleased, String pGenre, String pPlatform, String pImage, String pUserList, String pRating, String pSummary)
	{
		name = pName;
		developer = pDeveloper;
		publisher = pPublisher;
		yearReleased = pYearReleased;
		genre = pGenre;
		platform = pPlatform;
		image = pImage;
		userList = pUserList;
		rating = pRating;
		summary = pSummary;
	}
	
	//------------------------------------------------------------
	// Methods
	//------------------------------------------------------------
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String pName)
	{
		name = pName;
	}
	
	public String getDeveloper()
	{
		return developer;
	}
	
	public void setDeveloper(String pDeveloper)
	{
		developer = pDeveloper;
	}
	
	public String getPublisher()
	{
		return publisher;
	}
	
	public void setPublisher(String pPublisher)
	{
		publisher = pPublisher;
	}
	
	public String getYearReleased()
	{
		return yearReleased;
	}
	
	public void setYearReleased(String pYear)
	{
		yearReleased = pYear;
	}
	
	public String getImage()
	{
		return image;
	}
	
	public void setImage(String pImage)
	{
		image = pImage;
	}
	
	public String getGenre()
	{
		return genre;
	}
	
	public void setGenre(String pGenre)
	{
		genre = pGenre;
	}
	
	public String getSummary()
	{
		return summary;
	}
	
	public void setSummary(String pSummary)
	{
		summary = pSummary;
	}
}
