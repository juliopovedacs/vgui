package edu.ou.cs.hci.stages;

/**
 * Class that represents a Video Game
 */
public class VideoGame 
{
	//------------------------------------------------------------
	// Attributes
	//------------------------------------------------------------
	
	/**
	 * Video game name
	 */
	private String name;
	
	/**
	 * Video game developer
	 */
	private String developer;
	
	/**
	 * Video game publisher
	 */
	private String publisher;
	
	/**
	 * Video game year in which it was released
	 */
	private String year;
	
	/**
	 * Video game genre
	 */
	private String genre;
	
	/**
	 * Video game platform
	 */
	private String platform;
	
	/**
	 * Video game image
	 */
	private String image;
	
	/**
	 * User name of the video game
	 */
	private String userName;
	
	/**
	 * Categories in which the video game has been put into by its user
	 */
	private String userList;
	
	/**
	 * Video game rating
	 */
	private String rating;
	
	/**
	 * Video game description
	 */
	private String description;
	
	//------------------------------------------------------------
	// Constructor
	//------------------------------------------------------------
	
	/**
	 * Constructs a video game
	 * @param pName - Video game´s name
	 * @param pDeveloper - Video game´s developer
	 * @param pPublisher - Video game´s publisher
	 * @param pYear - Video game´s year in which it was released
	 * @param pGenre - Video game´s genre
	 * @param pPlatform - Video game´s platform
	 * @param pImage - Video game´s image
	 * @param pUserList - Video game´s categories in which it has been put into by the user
	 * @param pRating - Video game´s rating
	 * @param pDescription - Video game´s description
	 */
	public VideoGame(String pName, String pDeveloper, String pPublisher, String pYear, String pGenre, String pPlatform, String pImage, String pUserList, String pRating, String pDescription)
	{
		name = pName;
		developer = pDeveloper;
		publisher = pPublisher;
		year = pYear;
		genre = pGenre;
		platform = pPlatform;
		image = pImage;
		userList = pUserList;
		rating = pRating;
		description = pDescription;
	}
	
	//------------------------------------------------------------
	// Methods
	//------------------------------------------------------------
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String pName)
	{
		name = pName;
	}
	
	public String getDeveloper()
	{
		return developer;
	}
	
	public void setDeveloper(String pDeveloper)
	{
		developer = pDeveloper;
	}
	
	public String getPublisher()
	{
		return publisher;
	}
	
	public void setPublisher(String pPublisher)
	{
		publisher = pPublisher;
	}
	
	public String getYear()
	{
		return year;
	}
	
	public void setYear(String pYear)
	{
		year = pYear;
	}
	
	
}
