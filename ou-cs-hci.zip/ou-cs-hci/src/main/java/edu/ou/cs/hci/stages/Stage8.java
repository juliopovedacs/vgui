//******************************************************************************
// Copyright (C) 2016-2018 University of Oklahoma Board of Trustees.
//******************************************************************************
// Last modified: Tue Feb  9 20:33:16 2016 by Chris Weaver
//******************************************************************************
// Major Modification History:
//
// 20160209 [weaver]:	Original file (for CS 4053/5053 homeworks).
// 20180123 [weaver]:	Modified for use in CS 3053 team projects.
//
//******************************************************************************
// Notes:
//
//******************************************************************************

package edu.ou.cs.hci.stages;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

//******************************************************************************

/**
 * The <CODE>Stage8</CODE> class.<P>
 *
 * @author  Chris Weaver
 * @version %I%, %G%
 */
public final class Stage8
{
	//**********************************************************************
	// Public Class Members
	//**********************************************************************
	
	//--------------------------------------------------------------------------------------------
	// UI buttons
	//--------------------------------------------------------------------------------------------
	
	/**
	 * User image
	 */
	public static final String USER_IMAGE = "User image";
	
	/**
	 * Home
	 */
	public static final String HOME = "Home";
	
	/**
	 * Featured games
	 */
	public static final String FEATURED_GAMES = "Featured games";
	
	/**
	 * News and events
	 */
	public static final String NEWS_AND_EVENTS = "News and events";
	
	/**
	 * My games
	 */
	public static final String MY_GAMES = "My games";
	
	/**
	 * My favorites
	 */
	public static final String MY_FAVORITES = "My favorites";
	
	/**
	 * My wishlist
	 */
	public static final String MY_WISHLIST = "My wishlist";
	
	/**
	 * Recently played
	 */
	public static final String RECENTLY_PLAYED = "Recently played";
	
	/**
	 * Shuffle
	 */
	public static final String SHUFFLE = "Shuffle";
	
	/**
	 * Game
	 */
	public static final String GAME = "Game";
	
	/**
	 * Sort by
	 */
	public static final String SORT_BY = "Sort by";
	
	/**
	 * Search
	 */
	public static final String SEARCH = "Search";
	
	/**
	 * Selected video game image
	 */
	public static final String SELECTED_VIDEO_GAME_IMAGE = "Selected video game image";
	
	/**
	 * Game type
	 */
	public static final String GAME_LIBRARY = "Game library";
	
	/**
	 * Update
	 */
	public static final String UPDATE = "Update";
	
	/**
	 * Submit
	 */
	public static final String SUBMIT = "Submit";
	
	/**
	 * More
	 */
	public static final String MORE_INFO = "More info";
	
	//--------------------------------------------------------------------------------------------
	// Menu items
	//--------------------------------------------------------------------------------------------
	
	/**
	 * Open menu item
	 */
	public static JMenuItem openMenuItem;
	
	/**
	 * Save menu item
	 */
	public static JMenuItem saveMenuItem;
	
	/**
	 * Print menu item
	 */
	public static JMenuItem printMenuItem;
	
	/**
	 * Quit menu item
	 */
	public static JMenuItem quitMenuItem;
	
	/**
	 * Cut menu item
	 */
	public static JMenuItem cutMenuItem;
	
	/**
	 * Copy menu item
	 */
	public static JMenuItem copyMenuItem;
	
	/**
	 * Paste menu item
	 */
	public static JMenuItem pasteMenuItem;
	
	/**
	 * Grid menu item
	 */
	public static JMenuItem gridMenuItem;
	
	/**
	 * List menu item
	 */
	public static JMenuItem listMenuItem;
	
	/**
	 * Title AZ menu item
	 */
	public static JMenuItem titleAZMenuItem;
	
	/**
	 * Title ZA menu item
	 */
	public static JMenuItem titleZAMenuItem;
	
	/**
	 * Platform menu item
	 */
	public static JMenuItem platformMenuItem;
	
	/**
	 * Release date menu item
	 */
	public static JMenuItem releaseDateMenuItem;
	
	/**
	 * Sports menu item
	 */
	public static JMenuItem sportsMenuItem;
	
	/**
	 * War menu item
	 */
	public static JMenuItem warMenuItem;
	
	/**
	 * Narrative menu item
	 */
	public static JMenuItem narrativeMenuItem;
	
	/**
	 * Role play menu item
	 */
	public static JMenuItem rolePlayMenuItem;
	
	/**
	 * MOBA menu item
	 */
	public static JMenuItem mobaMenuItem;
	
	/**
	 * About us menu item
	 */
	public static JMenuItem aboutUsMenuItem;
	
	/**
	 * Create new profile menu item
	 */
	public static JMenuItem createNewProfileMenuItem;
	
	/**
	 * Settings menu item
	 */
	public static JMenuItem settingsMenuItem;
	
	/**
	 * Add new game menu item
	 */
	public static JMenuItem addNewGameMenuItem;
	
	/**
	 * Add new library menu item
	 */
	public static JMenuItem addNewLibraryMenuItem;
	
	/**
	 * My games menu item
	 */
	public static JMenuItem myGamesMenuItem;
	
	/**
	 * My favorites menu item
	 */
	public static JMenuItem myFavoritesMenuItem;
	
	/**
	 * My wishlist menu item
	 */
	public static JMenuItem myWishlistMenuItem;
	
	/**
	 * Recently played menu item
	 */
	public static JMenuItem recentlyPlayedMenuItem;
	
	/**
	 * Clear library menu item
	 */
	public static JMenuItem clearLibraryMenuItem;
	
	/**
	 * Delete library menu item
	 */
	public static JMenuItem deleteLibraryMenuItem;
	
	/**
	 * Share to Twitter menu item
	 */
	public static JMenuItem shareToTwitterMenuItem;
	
	/**
	 * Share to Facebook menu item
	 */
	public static JMenuItem shareToFacebookMenuItem;
	
	/**
	 * Discard menu item
	 */
	public static JMenuItem discardMenuItem;
	
	/**
	 * FAQ menu item
	 */
	public static JMenuItem faqMenuItem;
	
	/**
	 * Go to Steam menu item
	 */
	public static JMenuItem goToSteamMenuItem;
	
	//--------------------------------------------------------------------------------------------
	// Styled Application
	//--------------------------------------------------------------------------------------------
	
	/**
	 * Background color
	 */
	public static Color backgroundColor = Color.decode("#366AA0");
	
	/**
	 * Buttons color
	 */
	public static Color buttonsColor = Color.decode("#4796E8");
	
	/**
	 * Menubar submenu item font
	 */
	public static Font menubarSubMenuItemFont = new Font("Sans-Serif", Font.ITALIC, 14);
	
	/**
	 * Library name font
	 */
	public static Font libraryNameFont = new Font("Serif", Font.BOLD, 20);
	
	/**
	 * Selected game title and titled borders font
	 */
	public static Font selectedGameTitleAndTitledBordersFont = new Font("Serif", Font.BOLD, 15);
	
	/**
	 * Main frame
	 */
	public static JFrame frame;
	
	/**
	 * Left panel
	 */
	public static JPanel userPanel;
	
	/**
	 * Center panel
	 */
	public static JPanel gamesListPanel;
	
	/**
	 * Right panel
	 */
	public static JPanel selectedGamePanel;
	
	/**
	 * Resources
	 */
	public static Resources resources;
	
	/**
	 * Selected video game
	 */
	public static VideoGame selectedVideoGame;
	
	/**
	 * Video games
	 */
	public static ArrayList<VideoGame> videoGames;
	
	/**
	 * Changes in video games information
	 */
	public static boolean changes;
	
	/**
	 * Close about us window
	 */
	public static String CLOSE_ABOUT_US_WINDOW = "Close about us window";
		
	//**********************************************************************
	// Main
	//**********************************************************************

	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args)
	{
		System.out.println("---------------------------------------------------------------");
		System.out.println("-         Welcome to the Video Games browsing UI               -");
		System.out.println("---------------------------------------------------------------");
		
		System.out.println("");
		
		System.out.println("To begin, add some video games by clicking File > Open and selecting a csv file with video games info.");
		System.out.println("");
		
		// Main frame
		
		resources = new Resources();
		
		// Create Main Frame
		frame = new JFrame("Stage 8");		
		
		// Creates UserPanel, GamesListPanel and GameInformationPanel
		userPanel = new UserPanel();
		gamesListPanel = new GamesListPanel();
		selectedGamePanel = new SelectedGamePanel();

		// Sets Main Frame´s bounds, layout and background color
		frame.setBounds(50, 50, 800, 800);
		frame.getContentPane().setLayout(new BorderLayout());
		
		// Sets Panels size
		userPanel.setPreferredSize(new Dimension(150, 800));
		userPanel.setMaximumSize(userPanel.getPreferredSize());
		gamesListPanel.setPreferredSize(new Dimension(150, 800));
		gamesListPanel.setMaximumSize(userPanel.getPreferredSize());
		selectedGamePanel.setPreferredSize(new Dimension(400, 800));
		selectedGamePanel.setMaximumSize(userPanel.getPreferredSize());
		
		// Draws a border
		userPanel.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		gamesListPanel.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		selectedGamePanel.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		
		//--------------------------------------------------------------------------------------------
		// Menu bar
		//--------------------------------------------------------------------------------------------
		
		// Creates menu bar
		JMenuBar menubar = new JMenuBar();
		menubar.setForeground(buttonsColor);
		
		// File menu
		JMenu file = new JMenu("File");
		file.setMnemonic(KeyEvent.VK_F);
		
		// openMenuItem
		OpenAction openAction = new OpenAction("Open", "Open file");
		openMenuItem = new JMenuItem(openAction);
		openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
			    ActionEvent.CTRL_MASK));
		
		// saveMenuItem
		SaveAction saveAction = new SaveAction("Save", "Save file");
		saveMenuItem = new JMenuItem(saveAction);
		saveMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
			    ActionEvent.CTRL_MASK));
		
		// printMenuItem
		PrintAction printAction = new PrintAction("Print", "Print file");
		printMenuItem = new JMenuItem(printAction);
		printMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,
			    ActionEvent.CTRL_MASK));
		
		// quitMenuItem
		QuitAction quitAction = new QuitAction("Quit", "Quit");
		quitMenuItem = new JMenuItem(quitAction);
		quitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
			    ActionEvent.CTRL_MASK));
		
		// Adds menu items to file menu
		file.add(openMenuItem);
		file.add(saveMenuItem);
		file.add(printMenuItem);
		file.addSeparator();
		file.add(quitMenuItem);
		
		// Edit Menu
		JMenu edit = new JMenu("Edit");
		edit.setMnemonic(KeyEvent.VK_E);
		
		// cutMenuItem
		CutAction cutAction = new CutAction("Cut", "Cut");
		cutMenuItem = new JMenuItem(cutAction);
		cutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
			    ActionEvent.CTRL_MASK));
		
		// copyMenuItem
		CopyAction copyAction = new CopyAction("Copy", "Copy");
		copyMenuItem = new JMenuItem(copyAction);
		copyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
			    ActionEvent.CTRL_MASK));
		
		// pasteMenuItem
		PasteAction pasteAction = new PasteAction("Paste", "Paste");
		pasteMenuItem = new JMenuItem(pasteAction);
		pasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,
			    ActionEvent.CTRL_MASK));
		
		// Adds menu items to edit menu
		edit.add(cutMenuItem);
		edit.add(copyMenuItem);
		edit.add(pasteMenuItem);
		
		// View Menu
		JMenu view = new JMenu("View");
		view.setMnemonic(KeyEvent.VK_W);
				
		// viewAsSubMenu
		JMenu viewAsSubMenu = new JMenu("View as");
		viewAsSubMenu.setFont(menubarSubMenuItemFont);
				
		// gridMenuItem
		GridAction gridAction = new GridAction("Grid", "Show as grid");
		gridMenuItem = new JMenuItem(gridAction);
				
		// listMenuItem
		ListAction listAction = new ListAction("List", "Show as list");
		listMenuItem = new JMenuItem(listAction);
		
		// Adds gridMenuItem and listMenuItem to viewAsSubMenu
		viewAsSubMenu.add(gridMenuItem);
		viewAsSubMenu.add(listMenuItem);
		
		// sortSubMenu
		JMenu sortSubMenu = new JMenu("Sort by");
		sortSubMenu.setMnemonic(KeyEvent.VK_T);
		sortSubMenu.setFont(menubarSubMenuItemFont);
						
		// titleAZMenuItem
		TitleAZAction titleAZAction = new TitleAZAction("Title AZ", "Sort by title AZ");
		titleAZMenuItem = new JMenuItem(titleAZAction);
						
		// titleZAMenuItem
		TitleZAAction titleZAAction = new TitleZAAction("Title ZA", "Sort by title ZA");
		titleZAMenuItem = new JMenuItem(titleZAAction);
				
		// platformMenuItem
		PlatformAction platformAction = new PlatformAction("Platform", "Sort by platform");
		platformMenuItem = new JMenuItem(platformAction);
				
		// releaseDateMenuItem
		ReleaseDateAction releaseDateAction = new ReleaseDateAction("Release date", "Sort by release date");
		releaseDateMenuItem = new JMenuItem(releaseDateAction);
				
		// Adds titleAZMenuItem, titleZAMenuItem, platformMenuItem and releaseDateMenuItem to sortSubMenu
		sortSubMenu.add(titleAZMenuItem);
		sortSubMenu.add(titleZAMenuItem);
		sortSubMenu.add(platformMenuItem);
		sortSubMenu.add(releaseDateMenuItem);
				
		// filterSubMenu
		JMenu filterSubMenu = new JMenu("Filter by");
		filterSubMenu.setMnemonic(KeyEvent.VK_I);
		filterSubMenu.setFont(menubarSubMenuItemFont);
						
		// sportsMenuItem
		SportsAction sportsAction = new SportsAction("Sports", "Filter by sports");
		sportsMenuItem = new JMenuItem(sportsAction);
						
		// warMenuItem
		WarAction warAction = new WarAction("War", "Filter by war");
		warMenuItem = new JMenuItem(warAction);
				
		// narrativeMenuItem
		NarrativeAction narrativeAction = new NarrativeAction("Narrative", "Filter by narrative");
		narrativeMenuItem = new JMenuItem(narrativeAction);
				
		// rolePlayMenuItem
		RolePlayAction rolePlayAction = new RolePlayAction("Role play", "Filter by role play");
		rolePlayMenuItem = new JMenuItem(rolePlayAction);
				
		// mobaMenuItem
		MOBAAction mobaAction = new MOBAAction("MOBA", "Filter by MOBA");
		mobaMenuItem = new JMenuItem(mobaAction);
				
		// Adds sportsMenuItem, warMenuItem, narrativeMenuItem, rolePlayMenuItem and mobaMenuItem to filterSubMenu
		filterSubMenu.add(sportsMenuItem);
		filterSubMenu.add(warMenuItem);
		filterSubMenu.add(narrativeMenuItem);
		filterSubMenu.add(rolePlayMenuItem);
		filterSubMenu.add(mobaMenuItem);
				
		// Adds sub menus to view menu
		view.add(viewAsSubMenu);
		view.add(sortSubMenu);
		view.add(filterSubMenu);
		
		// About menu
				
		JMenu about = new JMenu("About");
		about.setMnemonic(KeyEvent.VK_A);
		
		// aboutUsMenuItem
		AboutUsAction aboutUsAction = new AboutUsAction("About us", "About us");
		aboutUsMenuItem = new JMenuItem(aboutUsAction);
		
		about.add(aboutUsMenuItem);
		
		// User menu
		JMenu user = new JMenu("User");
		file.setMnemonic(KeyEvent.VK_U);
				
		// createNewProfileMenuItem
		CreateNewProfileAction createNewProfileAction = new CreateNewProfileAction("Create new profile", "Create new profile");
		createNewProfileMenuItem = new JMenuItem(createNewProfileAction);
				
		// settingsMenuItem
		SettingsAction settingsAction = new SettingsAction("Settings", "Settings");
		settingsMenuItem = new JMenuItem(settingsAction);
				
		// Adds menu items to user menu
		user.add(createNewProfileMenuItem);
		user.add(settingsMenuItem);
		
		// Library menu
		JMenu library = new JMenu("Library");
		file.setMnemonic(KeyEvent.VK_L);
						
		// addNewGameMenuItem
		AddNewGameAction addNewGameAction = new AddNewGameAction("Add new game", "Add new game");
		addNewGameMenuItem = new JMenuItem(addNewGameAction);
						
		// addNewLibraryMenuItem
		AddNewLibraryAction addNewLibraryAction = new AddNewLibraryAction("Add new library", "Add new library");
		addNewLibraryMenuItem = new JMenuItem(addNewLibraryAction);
		
		// goToLibrarySubMenu
		JMenu goToLibrarySubMenu = new JMenu("Go To Library");
		goToLibrarySubMenu.setFont(menubarSubMenuItemFont);
				
		// myGamesMenuItem
		MyGamesAction myGamesAction = new MyGamesAction("My Games", "Go to My Games");
		myGamesMenuItem = new JMenuItem(myGamesAction);
		
		// myFavoritesMenuItem
		MyFavoritesAction myFavoritesAction = new MyFavoritesAction("My Favorites", "Go to My Favorites");
		myFavoritesMenuItem = new JMenuItem(myFavoritesAction);
		
		// myWishlistMenuItem
		MyWishlistAction myWishlistAction = new MyWishlistAction("My Wishlist", "Go to My Wishlist");
		myWishlistMenuItem = new JMenuItem(myWishlistAction);
		
		// recentlyPlayedMenuItem
		RecentlyPlayedAction recentlyPlayedAction = new RecentlyPlayedAction("Recently Played", "Go to Recently Played");
		recentlyPlayedMenuItem = new JMenuItem(recentlyPlayedAction);
		
		// Adds myGamesMenuItem, myFavoritesMenuItem, myWishlistMenuItem and recentlyPlayedMenuItem to goToLibrarySubMenu
		goToLibrarySubMenu.add(myGamesMenuItem);
		goToLibrarySubMenu.add(myFavoritesMenuItem);
		goToLibrarySubMenu.add(myWishlistMenuItem);
		goToLibrarySubMenu.add(recentlyPlayedMenuItem);
		
		// clearLibraryMenuItem
		ClearLibraryAction clearLibraryAction = new ClearLibraryAction("Clear library", "Clear library");
		clearLibraryMenuItem = new JMenuItem(clearLibraryAction);
		
		// deleteLibraryMenuItem
		DeleteLibraryAction deleteLibraryAction = new DeleteLibraryAction("Delete library", "Delete library");
		deleteLibraryMenuItem = new JMenuItem(deleteLibraryAction);
		
		// Adds menu items to library menu
		library.add(addNewGameMenuItem);
		library.add(addNewLibraryMenuItem);
		library.add(goToLibrarySubMenu);
		library.add(clearLibraryMenuItem);
		library.add(deleteLibraryMenuItem);
		
		// Share To menu
		JMenu shareTo = new JMenu("Share To");
		shareTo.setMnemonic(KeyEvent.VK_R);
						
		// shareToTwitterMenuItem
		ShareToTwitterAction shareToTwitterAction = new ShareToTwitterAction("Share To Twitter", "Share To Twitter");
		shareToTwitterMenuItem = new JMenuItem(shareToTwitterAction);
						
		// shareToFacebookMenuItem
		ShareToFacebookAction shareToFacebookAction = new ShareToFacebookAction("Share To Facebook", "Share To Facebook");
		shareToFacebookMenuItem = new JMenuItem(shareToFacebookAction);
		
		// DiscardMenuItem
		DiscordAction discardAction = new DiscordAction("Discard", "Discard");
		discardMenuItem = new JMenuItem(discardAction);
						
		// Adds menu items to shareTo menu
		shareTo.add(shareToTwitterAction);
		shareTo.add(shareToFacebookAction);
		shareTo.addSeparator();
		shareTo.add(discardMenuItem);
				
		// Help menu
		JMenu help = new JMenu("Help");
		help.setMnemonic(KeyEvent.VK_H);
						
		// faqMenuItem
		FAQAction faqAction = new FAQAction("FAQ", "FAQ", KeyEvent.VK_Z);
		faqMenuItem = new JMenuItem(faqAction);
						
		// goToSteamMenuItem
		GoToSteamAction goToSteamAction = new GoToSteamAction("Go To Steam", "Go To Steam", KeyEvent.VK_M);
		goToSteamMenuItem = new JMenuItem(goToSteamAction);
						
		// Adds menu items to help menu
		help.add(faqMenuItem);
		help.add(goToSteamMenuItem);
		
		// Adds menus to menu bar
		menubar.add(file);
		menubar.add(edit);
		menubar.add(view);
		menubar.add(about);
		menubar.add(user);
		menubar.add(library);
		menubar.add(shareTo);
		menubar.add(help);
		
		// Sets the menu bar for the frame
		frame.setJMenuBar(menubar);
		
		//--------------------------------------------------------------------------------------------
		// Tool bar
		//--------------------------------------------------------------------------------------------
		
		// Creates a tool bar
		JToolBar toolbar = new JToolBar();
		toolbar.setPreferredSize(new Dimension(800, 50));
				
		// ArrayList of tool bar clicked elements
		ArrayList<String> toolbarClickedElements = new ArrayList<String>();
		
		// Add new game tool bar button
		JButton addNewGameButton = new JButton(resources.getImage("icons/add.png"));
		addNewGameButton.setText("Add video game");
		addNewGameButton.setVerticalTextPosition(SwingConstants.BOTTOM);
		addNewGameButton.setHorizontalTextPosition(SwingConstants.CENTER);
		addNewGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		toolbarClickedElements.add("Clicked add in the toolbar. Adds new game to the library.");
                System.out.println("Clicked add in the toolbar. Adds new game to the library.");
            }
        });
		
		// View as grid tool bar button
		JButton gridButton = new JButton(resources.getImage("icons/grid.png"));
		gridButton.setText("View as grid");
		gridButton.setVerticalTextPosition(SwingConstants.BOTTOM);
		gridButton.setHorizontalTextPosition(SwingConstants.CENTER);
		gridButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		toolbarClickedElements.add("Clicked grid in the toolbar. Shows games as grid.");
                System.out.println("Clicked grid in the toolbar. Shows games as grid.");
            }
        });
				
		// View as list tool bar button
		JButton listButton = new JButton(resources.getImage("icons/list.png"));
		listButton.setText("View as list");
		listButton.setVerticalTextPosition(SwingConstants.BOTTOM);
		listButton.setHorizontalTextPosition(SwingConstants.CENTER);
		listButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		toolbarClickedElements.add("Clicked list in the toolbar. Shows games as list.");
                System.out.println("Clicked list in the toolbar. Shows games as list.");
            }
        });
		
		// Sort tool bar button
		JButton sortButton = new JButton(resources.getImage("icons/sort.png"));
		sortButton.setText("Sort");
		sortButton.setVerticalTextPosition(SwingConstants.BOTTOM);
		sortButton.setHorizontalTextPosition(SwingConstants.CENTER);
		sortButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		toolbarClickedElements.add("Clicked sort in the toolbar. Opens sort menu.");
                System.out.println("Clicked sort in the toolbar. Opens sort menu.");
            }
        });
		
		// Filter tool bar button
		JButton filterButton = new JButton(resources.getImage("icons/filter.png"));
		filterButton.setText("Filter");
		filterButton.setVerticalTextPosition(SwingConstants.BOTTOM);
		filterButton.setHorizontalTextPosition(SwingConstants.CENTER);
		filterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		toolbarClickedElements.add("Clicked filter in the toolbar. Opens filter menu.");
                System.out.println("Clicked filter in the toolbar. Opens filter menu.");
            }
        });
		
		// Adds buttons to toolbar
		toolbar.add(addNewGameButton);
		toolbar.addSeparator();
		toolbar.add(gridButton);
		toolbar.add(listButton);
		toolbar.addSeparator();
		toolbar.add(sortButton);
		toolbar.add(filterButton);
		
		toolbar.setBackground(backgroundColor);
				
		// Adds toolbar, userPanel, gamesListPanel and gameInformationPanel to Main Frame
		frame.getContentPane().add(toolbar, BorderLayout.NORTH);
		frame.getContentPane().add(userPanel, BorderLayout.WEST);
		frame.getContentPane().add(gamesListPanel, BorderLayout.CENTER);
		frame.getContentPane().add(selectedGamePanel, BorderLayout.EAST);
		
		frame.setVisible(true);
		JOptionPane.showMessageDialog(frame, "Hi! To begin, add some games please.");

		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				
				if (changes)
				  {
					  System.out.println("There were changes.");
					  System.out.println("");
					  
					  Object[] options = {"Quit without saving", "Cancel", "Save and Quit"};
					  
					  int n = JOptionPane.showOptionDialog(frame, "What would you like yo do?", "Exit", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
					  
					  if (n == 0)
					  {
						  // Quit without saving
						  
						  System.out.println("You selected Quit without saving");
						  System.out.println("");
						  
						  System.out.println("---------------------------------------------------------------");
						  System.out.println("-       Thank you for using the Video Games browsing UI        -");
					      System.out.println("---------------------------------------------------------------");
						  
						  System.exit(0);
					  }
					  else if (n == 1)
					  {
						  // Cancel
						  
						  System.out.println("You selected Cancel");
						  System.out.println("");
					  }
					  else if (n == 2)
					  {
						  // Save and Quit
						  
						  System.out.println("You selected Save and Quit");
						  System.out.println("");
						  
						// Creates file chooser
						JFileChooser fc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
						    
						// Creates a filter for fc
						FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV files", "csv");
						    
						// Sets filter for fc
						fc.setFileFilter(filter);
						    
						int returnValue = fc.showOpenDialog(null);
						    
						if (returnValue == JFileChooser.APPROVE_OPTION)
						{
							// The user selected a file
						    
							System.out.println("You selected " + fc.getSelectedFile());
							
							System.out.println("---------------------------------------------------------------");
							System.out.println("-       Thank you for using the Video Games browsing UI        -");
						    System.out.println("---------------------------------------------------------------");
							
							System.exit(0);
						}
						else
						{
						    // The user did not select a file
						    
							System.out.println("As you did not select a file, a file called output.csv was created (it is located inside ou-cs-hci with bin, build, build.gradle and src) and will have all changes made in the video games data.");
							System.out.println("");
								  
							File output = new File("output.csv");
								  			  
							FileOutputStream fos = null;
								  
							try 
							{
								fos = new FileOutputStream(output);
							} 
							catch (FileNotFoundException e1) 
							{
								e1.printStackTrace();
							}
										
							PrintStream ps = new PrintStream(fos);
							System.setOut(ps);
								  
							for (VideoGame vg: videoGames)
							{
								System.out.print("\"" + vg.getName() + "\",");
								System.out.print("\"" + vg.getDeveloper() + "\",");
								System.out.print("\"" + vg.getPublisher() + "\",");
								System.out.print("\"" + vg.getYearReleased() + "\",");
								System.out.print("\"" + vg.getGenre() + "\",");
								System.out.print("\"" + vg.getPlatforms() + "\",");
								System.out.print("\"" + vg.getImage() + "\",");
								System.out.print("\"" + vg.getLibrary() + "\",");
								System.out.print("\"" + vg.getRating() + "\",");
								System.out.print("\"" + vg.getSummary() + "\",");
								System.out.print("\"" + vg.getReviews() + "\",");
								System.out.print("\n");
							}
							
							try 
							{
								ps.close();
								fos.close();
							} 
							catch (IOException e1) 
							{
								e1.printStackTrace();
							}
							
							System.out.println("");
								  
							System.exit(0);
						 }
					  }
				   }
				   else
				   {
					   System.out.println("There were no changes.");
					   System.out.println("");
					   
					   System.out.println("---------------------------------------------------------------");
					   System.out.println("-       Thank you for using the Video Games browsing UI        -");
					   System.out.println("---------------------------------------------------------------");
					   
					   System.exit(0);
				   }
			}
		});
	}
	
	//--------------------------------------------------------------------------------------------
	// UI main panels
	//--------------------------------------------------------------------------------------------
	
	/**
	 * UserPanel
	 */
	private static final class UserPanel extends JPanel implements ActionListener
	{
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
		
		// Home button
		JButton homeButton;
		
		// Featured games button
		JButton featuredGamesButton;
		
		// News and events button
		JButton newsAndEventsButton;
		
		// My Games button
		JButton myGamesButton;
		
		// My Favorites button
		JButton myFavoritesButton;
		
		// My Wishlist button
		JButton myWishlistButton;
		
		// Recently Played button
		JButton recentlyPlayedButton;
		
		// Shuffle button
		JButton shuffleButton;
		
		/**
		 * UserPanel constructor
		 */
		public UserPanel() 
		{			
			// Sets layout
			setLayout(new BorderLayout());
			
			// Creates userImagePanel
			JPanel userImagePanel = new JPanel();
			userImagePanel.setLayout(new BorderLayout());
			userImagePanel.setBackground(backgroundColor);
			
			// Creates a button simulating an image
			JButton userImage = new JButton ("User image");
			userImage.setPreferredSize(new Dimension(100, 100));
			
			// Important for the button to work
			userImage.setActionCommand(USER_IMAGE);
			userImage.addActionListener(this);
			
			// Adds userImage to userImagePanel
			userImagePanel.add(userImage);
			
			// Creates optionsPanel
			JPanel optionsPanel = new JPanel();
			optionsPanel.setLayout(new GridLayout(12, 1));
			optionsPanel.setBackground(backgroundColor);
			
			// Creates homeButton
			homeButton = new JButton("Home");
			homeButton.setForeground(buttonsColor);
			homeButton.setActionCommand(HOME);
			homeButton.addActionListener(this);
			
			// Creates featuredGamesButton
			featuredGamesButton = new JButton("Featured Games");
			featuredGamesButton.setForeground(buttonsColor);
			featuredGamesButton.setActionCommand(FEATURED_GAMES);
			featuredGamesButton.addActionListener(this);
			
			// Creates newsAndEventsButton
			newsAndEventsButton = new JButton("News and Events");
			newsAndEventsButton.setForeground(buttonsColor);
			newsAndEventsButton.setActionCommand(NEWS_AND_EVENTS);
			newsAndEventsButton.addActionListener(this);
			
			// Creates myGamesButton
			myGamesButton = new JButton("My Games");
			myGamesButton.setForeground(buttonsColor);
			myGamesButton.setEnabled(false);
			myGamesButton.setActionCommand(MY_GAMES);
			myGamesButton.addActionListener(this);
			
			// Creates myFavoritesButton
			myFavoritesButton = new JButton("My Favorites");
			myFavoritesButton.setForeground(buttonsColor);
			myFavoritesButton.setEnabled(false);
			myFavoritesButton.setActionCommand(MY_FAVORITES);
			myFavoritesButton.addActionListener(this);
			
			// Creates myWishlistButton
			myWishlistButton = new JButton("My Wishlist");
			myWishlistButton.setForeground(buttonsColor);
			myWishlistButton.setEnabled(false);
			myWishlistButton.setActionCommand(MY_WISHLIST);
			myWishlistButton.addActionListener(this);
			
			// Creates recentlyPlayedButton
			recentlyPlayedButton = new JButton("Recently Played");
			recentlyPlayedButton.setForeground(buttonsColor);
			recentlyPlayedButton.setEnabled(false);
			recentlyPlayedButton.setActionCommand(RECENTLY_PLAYED);
			recentlyPlayedButton.addActionListener(this);
			
			// Creates shuffleButton
			shuffleButton = new JButton("Shuffle");
			shuffleButton.setForeground(buttonsColor);
			shuffleButton.setEnabled(false);
			shuffleButton.setActionCommand(SHUFFLE);
			shuffleButton.addActionListener(this);
			
			// Adds UI elements to optionsPanel
			optionsPanel.add(homeButton);
			optionsPanel.add(featuredGamesButton);
			optionsPanel.add(newsAndEventsButton);
			optionsPanel.add(new JLabel(""));
			optionsPanel.add(myGamesButton);
			optionsPanel.add(myFavoritesButton);
			optionsPanel.add(myWishlistButton);
			optionsPanel.add(recentlyPlayedButton);
			optionsPanel.add(new JLabel(""));
			optionsPanel.add(shuffleButton);
			
			// Adds panels to UserPanel
			add(userImagePanel, BorderLayout.NORTH);
			add(optionsPanel, BorderLayout.CENTER);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{			
			return uiUsedElements;
		}
		
		public void enableButtons()
		{
			myGamesButton.setEnabled(true);
			myFavoritesButton.setEnabled(true);
			myWishlistButton.setEnabled(true);
			recentlyPlayedButton.setEnabled(true);
			shuffleButton.setEnabled(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if (e.getActionCommand() == USER_IMAGE)
			{
				System.out.println("Clicked User image");
				uiUsedElements.add("Clicked user image");
			}
			else if (e.getActionCommand() == HOME)
			{
				System.out.println("Clicked Home");
				uiUsedElements.add("Clicked Home");
			}
			else if (e.getActionCommand() == FEATURED_GAMES)
			{
				System.out.println("Clicked Featured games");
				uiUsedElements.add("Clicked Featured games");
			}
			else if (e.getActionCommand() == NEWS_AND_EVENTS)
			{
				System.out.println("Clicked News and events");
				uiUsedElements.add("Clicked News and events");
			}
			else if (e.getActionCommand() == MY_GAMES)
			{
				System.out.println("Clicked My games");
				uiUsedElements.add("Clicked My games");
			}
			else if (e.getActionCommand() == MY_FAVORITES)
			{
				System.out.println("Clicked My favorites");
				uiUsedElements.add("Clicked My favorites");
			}
			else if (e.getActionCommand() == MY_WISHLIST)
			{
				System.out.println("Clicked My wishlist");
				uiUsedElements.add("Clicked My wishlist");
			}
			else if (e.getActionCommand() == RECENTLY_PLAYED)
			{
				System.out.println("Clicked Recently played");
				uiUsedElements.add("Clicked Recently played");
			}
			else if (e.getActionCommand() == SHUFFLE)
			{
				System.out.println("Clicked Shuffle");
				uiUsedElements.add("Clicked Shuffle");
			}
		}
	}

	/**
	 * GamesListPanel
	 */
	private static final class GamesListPanel extends JPanel implements ActionListener
	{
		// SearchSortPanel
		SearchSortPanel searchSortPanel;
		
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
		
		// LibraryNameAndGames panel
		JPanel libraryNameAndGamesPanel;
		
		// Display panel
		JPanel display;
				
		JScrollPane scrollPane;
		
		/**
		 * GamesListPanel constructor
		 */
		public GamesListPanel()
		{
			// Initializes SearchSortPanel
			searchSortPanel = new SearchSortPanel();
			
			videoGames = new ArrayList<VideoGame>();
			
			// Sets layout
			setLayout(new BorderLayout());
			
			// Library name plus Buttons panel
			libraryNameAndGamesPanel = new JPanel();
			libraryNameAndGamesPanel.setLayout(new BorderLayout());
			libraryNameAndGamesPanel.setBackground(backgroundColor);
			
			// Library name
			JLabel libraryName = new JLabel("Video Games", SwingConstants.CENTER);
			libraryName.setForeground(Color.WHITE);
			libraryName.setFont(libraryNameFont);
			
			// Creates display panel
			display = new JPanel();
			display.setBackground(backgroundColor);
			
			// Adds libraryName and display to libraryNameAndGamesPanel
			libraryNameAndGamesPanel.add(libraryName, BorderLayout.NORTH);
			libraryNameAndGamesPanel.add(display, BorderLayout.CENTER);
			
			// Adds searchSortPanel and libraryNameAndGamesPanel to GamesListPanel
			add(searchSortPanel, BorderLayout.NORTH);
			add(libraryNameAndGamesPanel, BorderLayout.CENTER);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{
			ArrayList<String> usedElements = new ArrayList<String>();
			
			usedElements = uiUsedElements;
					
			ArrayList<String> searchSortPanelUsedElements = searchSortPanel.getUsedElements();
			
			usedElements.addAll(searchSortPanelUsedElements);
			
			return usedElements;
		}
		
		/**
		 * Creates video games
		 * @param pVideoGames - Video games
		 */
		public void createVideoGames(ArrayList<VideoGame> pVideoGames)
		{			
			int numberOfVideoGames = pVideoGames.size();
			int numberOfRows = numberOfVideoGames / 2;
			
			display.setLayout(new GridLayout(numberOfRows, 2));
			
			int i = 1;
			
			for(VideoGame vg: pVideoGames)
			{
				JButton game = new JButton(vg.getName());
				game.setPreferredSize(new Dimension(100, 100));
				game.setMinimumSize(new Dimension(100, 100));

				game.setActionCommand(GAME);
				game.addActionListener((ActionListener) gamesListPanel);
				
				display.add(game);
				
				// Adds scroll pane
				scrollPane = new JScrollPane(display, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
				
				// Adds scrollPane to libraryNameAndGamesPanel
				libraryNameAndGamesPanel.add(scrollPane, BorderLayout.CENTER);
				
				libraryNameAndGamesPanel.revalidate();
				libraryNameAndGamesPanel.repaint();
				
				i++;
			}
		}
		
		/**
		 * Enables search field and sort by combo box
		 */
		public void enableUIElements()
		{
			searchSortPanel.enableSearchField();
			searchSortPanel.enableSortByComboBox();
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if (e.getActionCommand() == GAME)
			{
				// User clicked a game
				
				JButton clickedVideoGameButton = (JButton)e.getSource();
				uiUsedElements.add("Clicked " + clickedVideoGameButton.getText());
				
				System.out.println("You selected the video game " + clickedVideoGameButton.getText());
				System.out.println("");
				
				VideoGame clickedVideoGame = null;
				
				for(VideoGame vg: videoGames)
				{
					if (vg.getName().equals(clickedVideoGameButton.getText()))
					{
						clickedVideoGame = vg;
						selectedVideoGame = vg;
						break;
					}
				}
				
				((SelectedGamePanel) selectedGamePanel).updateInformation(clickedVideoGame);
			}
		}
	}
	
	/**
	 * SearchSortPanel
	 */
	public static final class SearchSortPanel extends JPanel implements ActionListener
	{
		/**
		 * Search field
		 */
		private JTextField searchField;
			
		/**
		 * Sort by combo box
		 */
		private JComboBox sortByComboBox;
		
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
			
		/**
		 * SearchSortPanel constructor
		 */
		public SearchSortPanel()
		{
			setBackground(backgroundColor);
			
			// Initializes search field
			searchField = new JTextField("Search", 16);
			searchField.setEnabled(false);
			searchField.setActionCommand(SEARCH);
			searchField.addActionListener(this);
				
			// Creates String array of sort by options
			String[] sortByOptions = {
					"Sort By:",
					"Title (A-Z)",
					"Title (Z-A)",
					"Platform",
					"Release Date"
			};
				
			// Initializes a  combo box
			sortByComboBox = new JComboBox(sortByOptions);
			sortByComboBox.setEnabled(false);
			sortByComboBox.setActionCommand(SORT_BY);
			sortByComboBox.addActionListener(this);
				
			// Sets layout
			setLayout(new BorderLayout());
				
			// Adds search text field and sort by combo box
			add(searchField, BorderLayout.CENTER);
			add(sortByComboBox, BorderLayout.EAST);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{			
			return uiUsedElements;
		}
		
		public void enableSearchField()
		{
			searchField.setEnabled(true);
		}
		
		public void enableSortByComboBox()
		{
			sortByComboBox.setEnabled(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if (e.getActionCommand() == SEARCH)
			{
				System.out.println("Search: " + searchField.getText());
				uiUsedElements.add("Search: " + searchField.getText());
			}
			else if (e.getActionCommand() == SORT_BY)
			{
				System.out.println("Sort by " + sortByComboBox.getSelectedItem());
				uiUsedElements.add("Sort by " + sortByComboBox.getSelectedItem());
			}
		}
	}
	
	/**
	 * GameInformationPanel
	 */
	private static final class SelectedGamePanel extends JPanel
	{
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
		
		// Basic info panel
		JPanel basicInfoPanel;
		
		// User info panel
		JPanel userInfoPanel;
		
		// BasicInfoAndUserInfo panel
		JPanel basicInfoAndUserInfoPanel;
		
		// Reviews panel
		JPanel reviewsPanel;
				
		/**
		 * SelectedGamePanel constructor
		 */
		public SelectedGamePanel()
		{
			// Sets layout
			setLayout(new BorderLayout());
			
			setBackground(backgroundColor);
			
			// Adds panels
			// Creates panels
			basicInfoAndUserInfoPanel = new JPanel();
			basicInfoAndUserInfoPanel.setLayout(new BorderLayout());
			
			basicInfoPanel = new SelectedVideoGameBasicInfoPanel();
			
			userInfoPanel = new SelectedVideoGameUserInfoPanel();
									
			basicInfoAndUserInfoPanel.add(basicInfoPanel, BorderLayout.NORTH);
			basicInfoAndUserInfoPanel.add(userInfoPanel, BorderLayout.CENTER);
			
			reviewsPanel = new SelectedVideoGameReviewsPanel();
			
			add(basicInfoAndUserInfoPanel, BorderLayout.NORTH);
			add(reviewsPanel, BorderLayout.CENTER);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{
			ArrayList<String> usedElements = new ArrayList<String>();
			
			ArrayList<String> usedElementsBasicInfoPanel = ((SelectedVideoGameBasicInfoPanel) basicInfoPanel).getUsedElements();
			
			ArrayList<String> usedElementsUserInfoPanel = ((SelectedVideoGameUserInfoPanel) userInfoPanel).getUsedElements();
			
			ArrayList<String> usedElementsReviewsPanel = ((SelectedVideoGameReviewsPanel) reviewsPanel).getUsedElements();

			usedElementsBasicInfoPanel.addAll(usedElementsUserInfoPanel);
			
			usedElementsBasicInfoPanel.addAll(usedElementsReviewsPanel);
			
			usedElements = usedElementsBasicInfoPanel;

			
			return usedElements;
		}
		
		public void updateInformation(VideoGame pVideoGame)
		{
			selectedVideoGame = pVideoGame;
			
			((SelectedVideoGameBasicInfoPanel) basicInfoPanel).updateBasicInfoPanelInformation(pVideoGame);
			
			selectedGamePanel.revalidate();
			selectedGamePanel.repaint();
		}
		
		public void enableUIElements()
		{
			((SelectedVideoGameUserInfoPanel) userInfoPanel).enableGameLibraryComboBox();
			((SelectedVideoGameUserInfoPanel) userInfoPanel).enableUpdateButton();
			
			((SelectedVideoGameReviewsPanel) reviewsPanel).enableTextArea();
			((SelectedVideoGameReviewsPanel) reviewsPanel).enableSubmitButton();
		}
	}
	
	/**
	 * SelectedVideoGameBasicInfoPanel
	 */
	private static final class SelectedVideoGameBasicInfoPanel extends JPanel implements ActionListener
	{
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
		
		JButton videoGameImage;
		
		JLabel selectedVideoGameTitle;
		
		JLabel selectedVideoGameGenre;
		
		JLabel selectedVideoGameYearReleased;
		
		JLabel summaryLabel;
		
		JPanel imageAndInfoPanel;
		
		/**
		 * SelectedVideoGameBasicInfoPanel constructor
		 */
		public SelectedVideoGameBasicInfoPanel()
		{
			// Sets layout
			setLayout(new BorderLayout());
			
			// Image and info panel
			imageAndInfoPanel = new JPanel();
			imageAndInfoPanel.setLayout(new BorderLayout());
			imageAndInfoPanel.setBackground(backgroundColor);
						
			// Video Game image
			
			videoGameImage = new JButton("No image");
			videoGameImage.setPreferredSize(new Dimension(200, 200));
			videoGameImage.setActionCommand(SELECTED_VIDEO_GAME_IMAGE);
			videoGameImage.addActionListener(this);
			
			// Information panel
			JPanel infoPanel = new JPanel();
			infoPanel.setLayout(new BorderLayout());
			infoPanel.setBackground(backgroundColor);
			
			// Video game title
			selectedVideoGameTitle = new JLabel("No video game selected");
			selectedVideoGameTitle.setForeground(Color.WHITE);
			selectedVideoGameTitle.setFont(selectedGameTitleAndTitledBordersFont);
			
			// Genre and year released panel
			JPanel genreAndYearReleasedPanel = new JPanel();
			genreAndYearReleasedPanel.setLayout(new BorderLayout());
			genreAndYearReleasedPanel.setBackground(backgroundColor);
			
			// Sets a titled border for genreAndYearReleasedPanel
			TitledBorder genreAndYearReleasedPanelBorder = new TitledBorder("");
			genreAndYearReleasedPanelBorder.setTitleColor(Color.WHITE);
			genreAndYearReleasedPanel.setBorder(genreAndYearReleasedPanelBorder);
			
			// Genre and year released labels
			selectedVideoGameGenre = new JLabel("<html><strong>Genre: </strong>" + " - " + " </html>");
			selectedVideoGameGenre.setForeground(Color.WHITE);
			selectedVideoGameYearReleased = new JLabel("<html><strong>Year released: </strong>" + " - " + " </html>");
			selectedVideoGameYearReleased.setForeground(Color.WHITE);
			
			// Adds genre and year released to genreAndYearReleasedPanel
			genreAndYearReleasedPanel.add(selectedVideoGameGenre, BorderLayout.NORTH);
			genreAndYearReleasedPanel.add(selectedVideoGameYearReleased, BorderLayout.CENTER);
			
			// Adds title and genreAndYearReleasedPanel to infoPanel
			infoPanel.add(selectedVideoGameTitle, BorderLayout.NORTH);
			infoPanel.add(genreAndYearReleasedPanel,BorderLayout.CENTER);
			
			// Adds image and infoPanel to imageAndInfoPanel
			imageAndInfoPanel.add(videoGameImage, BorderLayout.WEST);
			imageAndInfoPanel.add(infoPanel, BorderLayout.CENTER);
			
			// Adds imageAndInfoPanel to SelectedVideoGameBasicInfoPanel
			add(imageAndInfoPanel, BorderLayout.CENTER);
			
			// Creates summaryPanel and sets its layout
			JPanel summaryPanel = new JPanel();
			summaryPanel.setLayout(new BorderLayout());
			summaryPanel.setBackground(backgroundColor);
			
			// Creates summary label and adds it to summaryPanel
			summaryLabel = new JLabel("No summary available.");
			summaryLabel.setForeground(Color.WHITE);
			summaryPanel.add(summaryLabel, BorderLayout.CENTER);
			
			// Sets a titled border for summaryPanel
			TitledBorder summaryBorder = new TitledBorder("Summary");
			summaryBorder.setTitleColor(Color.WHITE);
			summaryBorder.setTitleFont(selectedGameTitleAndTitledBordersFont);
			summaryPanel.setBorder(summaryBorder);
			
			// Adds summaryPanel to SelectedVideoGameBasicInfoPanel
			add(summaryPanel, BorderLayout.SOUTH);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{			
			return uiUsedElements;
		}
		
		public void updateBasicInfoPanelInformation(VideoGame pVideoGame)
		{
			// Updates image
			String image = pVideoGame.getImage();
			videoGameImage.setIcon(resources.getImage("images/"+ image));
						
			// Updates name
			String name = pVideoGame.getName();
			selectedVideoGameTitle.setText(name);
			
			// Updates genre
			String genre = "<html><strong>Genre: </strong>" + pVideoGame.getGenre() + " </html>";
			selectedVideoGameGenre.setText(genre);
			
			// Updates year released
			String yearReleased = "<html><strong>Year released: </strong>" + pVideoGame.getYearReleased() + " </html>";
			selectedVideoGameYearReleased.setText(yearReleased);
			
			String summary = pVideoGame.getSummary();
			summaryLabel.setText(summary);
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if (e.getActionCommand() == SELECTED_VIDEO_GAME_IMAGE)
			{
				System.out.println("Clicked selected video game image");
				uiUsedElements.add("Clicked selected video game image");
			}
		}
	}
	
	/**
	 * SelectedVideoGameUserInfoPanel
	 */
	private static final class SelectedVideoGameUserInfoPanel extends JPanel implements ActionListener
	{
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
		
		/**
		 * Game type combo box
		 */
		private JComboBox gameLibraryComboBox;
		
		/**
		 * Update button
		 */
		private JButton updateButton;
		
		VideoGame selectedVideoGameUserInfoPanel;
				
		/**
		 * SelectedVideoGameUserInfoPanel constructor
		 */
		public SelectedVideoGameUserInfoPanel()
		{
			// Sets layout
			setLayout(new GridLayout(2,2));
			
			setBackground(backgroundColor);
			
			// Sets a titled border for SelectedVideoGameUserInfoPanel
			TitledBorder userInfoPanelBorder = new TitledBorder("More info");
			userInfoPanelBorder.setTitleColor(Color.WHITE);
			userInfoPanelBorder.setTitleFont(selectedGameTitleAndTitledBordersFont);
			setBorder(userInfoPanelBorder);
			
			// Creates hoursPlayed and achievements labels
			JLabel hoursPlayedLabel = new JLabel("Choose library: ");
			hoursPlayedLabel.setForeground(Color.WHITE);
			
			// Creates array of strings
			String[] gameComboBoxOptions = {
				"My Games",
				"My Favorites",
				"My Wishlist",
				"Recently Played"
			};
			
			// Initializes a combo box
			gameLibraryComboBox = new JComboBox(gameComboBoxOptions);
			gameLibraryComboBox.setEnabled(false);
			gameLibraryComboBox.setActionCommand(GAME_LIBRARY);
			gameLibraryComboBox.addActionListener(this);
			
			// Creates a button
			updateButton = new JButton("Update");
			updateButton.setEnabled(false);
			updateButton.setForeground(buttonsColor);
			updateButton.setActionCommand(UPDATE);
			updateButton.addActionListener(this);
			
			// Adds GUI elements to the panel
			add(hoursPlayedLabel);
			add(new JLabel(""));
			add(gameLibraryComboBox);
			add(updateButton);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{			
			return uiUsedElements;
		}
		
		public void enableGameLibraryComboBox()
		{
			gameLibraryComboBox.setEnabled(true);
		}
		
		public void enableUpdateButton()
		{
			updateButton.setEnabled(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if (e.getActionCommand() == GAME_LIBRARY)
			{
				System.out.println("Game library: " + gameLibraryComboBox.getSelectedItem());
				System.out.println("");
				
				uiUsedElements.add("Game library: " + gameLibraryComboBox.getSelectedItem());
			}
			else if (e.getActionCommand() == UPDATE)
			{
				System.out.println("Clicked Update " + gameLibraryComboBox.getSelectedItem());
				System.out.println("");
				int user_answer = JOptionPane.showConfirmDialog(this, "Are you sure you want to update the video game´s library?");
				
				if (user_answer == 0)
				{
					// User wants to update video game library
					
					String selectedVideoGameName = selectedVideoGame.getName();
					String newLibrary = gameLibraryComboBox.getSelectedItem().toString();
					
					for (int i = 0; i< videoGames.size(); i++)
					{
						if (videoGames.get(i).getName() == selectedVideoGameName)
						{
							// Update library
							videoGames.get(i).setLibrary(newLibrary);
							changes = true;
						}
					}
					
					System.out.println("You updated the library for " + selectedVideoGameName + ".");
					System.out.println("");
					
					System.out.println("The new library for " + selectedVideoGameName + " is " + newLibrary + ".");
					System.out.println("");
										
					JOptionPane.showMessageDialog(frame,
						    "Video game library updated");
				}
				else if (user_answer == 1)
				{
					// User does not want to update video game library
					
					JOptionPane.showMessageDialog(frame,
						    "Video game library was not updated");
				}
				else if (user_answer == 2)
				{
					// User clicked cancel
				}
				
				uiUsedElements.add("Clicked Update " + gameLibraryComboBox.getSelectedItem());
			}
		}
	}
	
	/**
	 * SelectedVideoGameReviewsPanel
	 */
	private static final class SelectedVideoGameReviewsPanel extends JPanel implements ActionListener
	{
		// Used UI elements
		ArrayList<String> uiUsedElements = new ArrayList<String>();
		
		/**
		 * Reviews text area
		 */
		private JTextArea reviewsTextArea;
		
		private JButton submitButton;
		
		/**
		 * SelectedVideoGameReviewsPanel constructor
		 */
		public SelectedVideoGameReviewsPanel()
		{
			// Sets layout
			setLayout(new BorderLayout());
			
			setBackground(backgroundColor);
			
			// Sets a titled border for SelectedVideoGameReviewsPanel
			TitledBorder reviewsPanelBorder = new TitledBorder("Reviews");
			reviewsPanelBorder.setTitleColor(Color.WHITE);
			reviewsPanelBorder.setTitleFont(selectedGameTitleAndTitledBordersFont);
			setBorder(reviewsPanelBorder);
			
			// Initializes reviews text area
			reviewsTextArea = new JTextArea();
			reviewsTextArea.setEnabled(false);
			reviewsTextArea.setLineWrap(true);
			reviewsTextArea.setWrapStyleWord(true);
			
			JPanel submitButtonPanel = new JPanel();
			submitButtonPanel.setLayout(new BorderLayout());
			
			// Creates the submit button
			submitButton = new JButton("Submit");
			submitButton.setEnabled(false);
			submitButton.setPreferredSize(new Dimension(100, 50));
			submitButton.setForeground(buttonsColor);
			submitButton.setActionCommand(SUBMIT);
			submitButton.addActionListener(this);
			
			submitButtonPanel.add(submitButton, BorderLayout.SOUTH);

			
			// Adds GUI elements to SelectedVideoGameReviewsPanel
			add(reviewsTextArea, BorderLayout.CENTER);
			add(submitButtonPanel, BorderLayout.SOUTH);
		}
		
		/**
		 * Returns array of used UI elements
		 * @return uiUsedElements
		 */
		public ArrayList<String> getUsedElements()
		{			
			return uiUsedElements;
		}
		
		/**
		 * Enables text area
		 */
		public void enableTextArea()
		{
			reviewsTextArea.setEnabled(true);
		}
		
		/**
		 * Enables submit button
		 */
		public void enableSubmitButton()
		{
			submitButton.setEnabled(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if (e.getActionCommand() == SUBMIT)
			{
				System.out.println("Clicked Submit: " + reviewsTextArea.getText());
				System.out.println("");
				
				int user_answer = JOptionPane.showConfirmDialog(this, "Are you sure you want to submit the video game´s review?");
				
				if (user_answer == 0)
				{
					// User wants to submit the video game´s review
					
					String selectedVideoGameName = selectedVideoGame.getName();
					String newReview = reviewsTextArea.getText();
					
					for (int i = 0; i< videoGames.size(); i++)
					{
						if (videoGames.get(i).getName() == selectedVideoGameName)
						{
							// Add review
							videoGames.get(i).addReview(newReview);
							changes = true;
						}
					}
					
					System.out.println("You added a review for " + selectedVideoGameName + ".");
					System.out.println("");
					
					System.out.println("This is what you submitted as review:  " + newReview + ".");
					System.out.println("");
					
					JOptionPane.showMessageDialog(frame,
						    "Review submitted!");
				}
				else if (user_answer == 1)
				{
					// User does not want to submit the video game´s review
					
					JOptionPane.showMessageDialog(frame,
						    "The review was not submitted.");
				}
				else if (user_answer == 2)
				{
					// User clicked cancel
				}
				
				uiUsedElements.add("Clicked Submit: " + reviewsTextArea.getText());
			}
		}
	}
	
	//--------------------------------------------------------------------------------------------
	// Menu bar actions
	//--------------------------------------------------------------------------------------------
		
	/**
	 * Open action
	 */
	private static final class OpenAction extends AbstractAction
	{
	  public OpenAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked File > Open");
	    System.out.println("");
	    
	    // Creates file chooser
	    JFileChooser fc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
	    
	    // Creates a filter for fc
	    FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV files", "csv");
	    
	    // Sets filter for fc
	    fc.setFileFilter(filter);
	    
	    int returnValue = fc.showOpenDialog(null);
	    
	    if (returnValue == JFileChooser.APPROVE_OPTION)
	    {
	    		// The user selected a file
	    		
	    		File selectedFile = fc.getSelectedFile();
			System.out.println("The application will read video games from " + selectedFile.getAbsolutePath());
			System.out.println("");
			
			BufferedReader br = null;
			String line = "";
			String splitBy = ",";
			
			try
			{
				br = new BufferedReader(new FileReader(selectedFile));
				int count = 1;
				
				videoGames = new ArrayList<VideoGame>();
				
				System.out.println("These are the video games that the application read: ");
				System.out.println("");
				
				while ((line = br.readLine()) != null)
				{
					// Coma is separator
					String[] videoGame = line.split(splitBy);
					
					String name = videoGame[0].replaceAll("\"", "");
					String developer = videoGame[1].replaceAll("\"", "");
					String publisher = videoGame[2].replaceAll("\"", "");
					String year = videoGame[3].replaceAll("\"", "");
					String genre = videoGame[4].replaceAll("\"", "");
					String platforms = videoGame[5].replaceAll("\"", "");
					String image = videoGame[6].replaceAll("\"", "");
					String library = videoGame[7].replaceAll("\"", "");
					String rating = videoGame[8].replaceAll("\"", "");
					String description = videoGame[9].replaceAll("\"", "");
					String reviews = videoGame[10].replaceAll("\"", "");
					
					System.out.println("                  Game " + count + "                ");
					System.out.println("--------------------------------------------");
					System.out.println("Name: " + name);
					System.out.println("Developer: " + developer);
					System.out.println("Publisher: " + publisher);
					System.out.println("Year: " + year);
					System.out.println("Genre: " + genre);
					System.out.println("Platforms: " + platforms);
					System.out.println("Image: " + image);
					System.out.println("Library: " + library);
					System.out.println("Rating: " + rating);
					System.out.println("Description: " + description);
					System.out.println("Reviews: " + reviews);
					System.out.println("");
					
					count++;
					
					videoGames.add(new VideoGame(name, developer, publisher, year, genre, platforms, image, library, rating, description, reviews));
				}
								
				// Create each video game in the UI
				((GamesListPanel) gamesListPanel).createVideoGames(videoGames);
				
				// Enable all buttons of userPanel
				((UserPanel) userPanel).enableButtons();
				
				// Enable UI elements of gamesListPanel
				((GamesListPanel) gamesListPanel).enableUIElements();
				
				// Enable UI elements of selectedGamePanel
				((SelectedGamePanel) selectedGamePanel).enableUIElements();
				
				changes = false;
				
				System.out.println("Click one video game in the center panel to see detailed information about it in the right panel.");
				System.out.println("");
			}
			catch (Exception e1)
			{
				JOptionPane.showMessageDialog(frame, "The file does not have a valid format", "Error reading the file", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
			finally
			{
				try
				{
					br.close();
				}
				catch (IOException e2)
				{
					e2.printStackTrace();
				}
			}
	    }
	    else
	    {
	    		// The user did not select a file
	    	
	    		JOptionPane.showMessageDialog(frame, "You did not select a file", "Error selecting file", JOptionPane.ERROR_MESSAGE);
	    }
	  }
	}
	
	/**
	 * Save action
	 */
	private static final class SaveAction extends AbstractAction
	{
	  public SaveAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked File > Save");
	  }
	}
	
	/**
	 * Print action
	 */
	private static final class PrintAction extends AbstractAction
	{
	  public PrintAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked File > Print");
	  }
	}
	
	/**
	 * Quit action
	 */
	private static final class QuitAction extends AbstractAction
	{
	  public QuitAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
		  System.out.println("Clicked File > Quit");
		  System.out.println("");
		  		 
		  if (changes)
		  {
			  System.out.println("There were changes.");
			  System.out.println("");
			  
			  Object[] options = {"Quit without saving", "Cancel", "Save and Quit"};
			  
			  int n = JOptionPane.showOptionDialog(frame, "What would you like yo do?", "Exit", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
			  
			  if (n == 0)
			  {
				  // Quit without saving
				  
				  System.out.println("You selected Quit without saving");
				  System.out.println("");
				  
				  System.out.println("---------------------------------------------------------------");
				  System.out.println("-       Thank you for using the Video Games browsing UI        -");
			      System.out.println("---------------------------------------------------------------");
				  
				  System.exit(0);
			  }
			  else if (n == 1)
			  {
				  // Cancel
				  
				  System.out.println("You selected Cancel");
				  System.out.println("");
			  }
			  else if (n == 2)
			  {
				  // Save and Quit
				  
				  System.out.println("You selected Save and Quit");
				  System.out.println("");
				  
				// Creates file chooser
				JFileChooser fc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
				    
				// Creates a filter for fc
				FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV files", "csv");
				    
				// Sets filter for fc
				fc.setFileFilter(filter);
				    
				int returnValue = fc.showOpenDialog(null);
				    
				if (returnValue == JFileChooser.APPROVE_OPTION)
				{
					// The user selected a file
				    
					System.out.println("You selected " + fc.getSelectedFile());
					
					System.out.println("---------------------------------------------------------------");
					System.out.println("-       Thank you for using the Video Games browsing UI        -");
				    System.out.println("---------------------------------------------------------------");
					
					System.exit(0);
				}
				else
				{
				    // The user did not select a file
				    
					System.out.println("As you did not select a file, a file called output.csv was created (it is located inside ou-cs-hci with bin, build, build.gradle and src) and will have all changes made in the video games data.");
					System.out.println("");
						  
					File output = new File("output.csv");
						  			  
					FileOutputStream fos = null;
						  
					try 
					{
						fos = new FileOutputStream(output);
					} 
					catch (FileNotFoundException e1) 
					{
						e1.printStackTrace();
					}
								
					PrintStream ps = new PrintStream(fos);
					System.setOut(ps);
						  
					for (VideoGame vg: videoGames)
					{
						System.out.print("\"" + vg.getName() + "\",");
						System.out.print("\"" + vg.getDeveloper() + "\",");
						System.out.print("\"" + vg.getPublisher() + "\",");
						System.out.print("\"" + vg.getYearReleased() + "\",");
						System.out.print("\"" + vg.getGenre() + "\",");
						System.out.print("\"" + vg.getPlatforms() + "\",");
						System.out.print("\"" + vg.getImage() + "\",");
						System.out.print("\"" + vg.getLibrary() + "\",");
						System.out.print("\"" + vg.getRating() + "\",");
						System.out.print("\"" + vg.getSummary() + "\",");
						System.out.print("\"" + vg.getReviews() + "\",");
						System.out.print("\n");
					}
					
					try 
					{
						ps.close();
						fos.close();
					} 
					catch (IOException e1) 
					{
						e1.printStackTrace();
					}
					
					System.out.println("");
						  
					System.exit(0);
				 }
			  }
		   }
		   else
		   {
			   System.out.println("There were no changes.");
			   System.out.println("");
			   
			   System.out.println("---------------------------------------------------------------");
			   System.out.println("-       Thank you for using the VideoGames browsing UI        -");
			   System.out.println("---------------------------------------------------------------");
			   
			   System.exit(0);
		   }
	  }
	}
	
	/**
	 * Cut action
	 */
	private static final class CutAction extends AbstractAction
	{
	  public CutAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Edit > Cut");
	  }
	}
	
	/**
	 * Copy action
	 */
	private static final class CopyAction extends AbstractAction
	{
	  public CopyAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Edit > Copy");
	  }
	}
	
	/**
	 * Paste action
	 */
	private static final class PasteAction extends AbstractAction
	{
	  public PasteAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Edit > Paste");
	  }
	}
	
	/**
	 * Grid action
	 */
	private static final class GridAction extends AbstractAction
	{
	  public GridAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > View as > Grid");
	  }
	}
	
	/**
	 * List action
	 */
	private static final class ListAction extends AbstractAction
	{
	  public ListAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > View as > List");
	  }
	}
	
	/**
	 * Title AZ action
	 */
	private static final class TitleAZAction extends AbstractAction
	{
	  public TitleAZAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Sort by > Title (A-Z)");
	  }
	}
	
	/**
	 * Title ZA action
	 */
	private static final class TitleZAAction extends AbstractAction
	{
	  public TitleZAAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Sort by > Title (Z-A)");
	  }
	}
	
	/**
	 * Platform action
	 */
	private static final class PlatformAction extends AbstractAction
	{
	  public PlatformAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Sort by > Platform");
	  }
	}
	
	/**
	 * Release date action
	 */
	private static final class ReleaseDateAction extends AbstractAction
	{
	  public ReleaseDateAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Sort by > Release Date");
	  }
	}
	
	/**
	 * Sports action
	 */
	private static final class SportsAction extends AbstractAction
	{
	  public SportsAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Filter by > Sports");
	  }
	}
	
	/**
	 * War action
	 */
	private static final class WarAction extends AbstractAction
	{
	  public WarAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Filter by > War");
	  }
	}
	
	/**
	 * Narrative action
	 */
	private static final class NarrativeAction extends AbstractAction
	{
	  public NarrativeAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Filter by > Narrative");
	  }
	}
	
	/**
	 * Role play action
	 */
	private static final class RolePlayAction extends AbstractAction
	{
	  public RolePlayAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Filter by > Role-Play");
	  }
	}
	
	/**
	 * MOBA action
	 */
	private static final class MOBAAction extends AbstractAction
	{
	  public MOBAAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked View > Filter by > MOBA");
	  }
	}
	
	/**
	 * Create new profile action
	 */
	private static final class CreateNewProfileAction extends AbstractAction
	{
	  public CreateNewProfileAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked User > Create new profile");
	  }
	}
	
	/**
	 * Settings action
	 */
	private static final class SettingsAction extends AbstractAction
	{
	  public SettingsAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked User > Settings");
	  }
	}
	
	/**
	 * Add new game action
	 */
	private static final class AddNewGameAction extends AbstractAction
	{
	  public AddNewGameAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Add New Game");
	  }
	}
	
	/**
	 * Add new library action
	 */
	private static final class AddNewLibraryAction extends AbstractAction
	{
	  public AddNewLibraryAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Add New Library");
	  }
	}
	
	/**
	 * My games action
	 */
	private static final class MyGamesAction extends AbstractAction
	{
	  public MyGamesAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Go To Library > My Games");
	  }
	}
	
	/**
	 * My favorites action
	 */
	private static final class MyFavoritesAction extends AbstractAction
	{
	  public MyFavoritesAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Go To Library > My Favorites");
	  }
	}
	
	/**
	 * My wishlist action
	 */
	private static final class MyWishlistAction extends AbstractAction
	{
	  public MyWishlistAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Go To Library > My Wishlist");
	  }
	}
	
	/**
	 * Recently Played action
	 */
	private static final class RecentlyPlayedAction extends AbstractAction
	{
	  public RecentlyPlayedAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Go To Library > Recently Played");
	  }
	}
	
	/**
	 * Clear library action
	 */
	private static final class ClearLibraryAction extends AbstractAction
	{
	  public ClearLibraryAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Clear Library");
	  }
	}
	
	/**
	 * Delete Library action
	 */
	private static final class DeleteLibraryAction extends AbstractAction
	{
	  public DeleteLibraryAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Library > Delete Library");
	  }
	}
	
	/**
	 * Share to Twitter action
	 */
	private static final class ShareToTwitterAction extends AbstractAction
	{
	  public ShareToTwitterAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Share To > Twitter");
	  }
	}
	
	/**
	 * Share to Facebook action
	 */
	private static final class ShareToFacebookAction extends AbstractAction
	{
	  public ShareToFacebookAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Share To > Facebook");
	  }
	}
	
	/**
	 * Discord action
	 */
	private static final class DiscordAction extends AbstractAction
	{
	  public DiscordAction(String name, String shortDescription)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Share To > Discord");
	  }
	}
	
	/**
	 * FAQ action
	 */
	private static final class FAQAction extends AbstractAction
	{
	  public FAQAction(String name, String shortDescription, int mnemonic)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	    putValue(MNEMONIC_KEY, mnemonic);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Help > FAQ");
	  }
	}
	
	/**
	 * Go to Steam action
	 */
	private static final class GoToSteamAction extends AbstractAction
	{
	  public GoToSteamAction(String name, String shortDescription, int mnemonic)
	  {
	    super(name);
	    putValue(SHORT_DESCRIPTION, shortDescription);
	    putValue(MNEMONIC_KEY, mnemonic);
	  }

	  public void actionPerformed(ActionEvent e)
	  {
	    System.out.println("Clicked Help > Go to Steam");
	  }
	}
	
	/**
	 * About us action
	 */
	private static final class AboutUsAction extends AbstractAction
	{
		public AboutUsAction(String name, String shortDescription)
		{
			super(name);
			putValue(SHORT_DESCRIPTION, shortDescription);
		}
		
		public void actionPerformed(ActionEvent e)
		{
			
			// Creates a new window
			JWindow aboutUsWindow = new JWindow(frame);
				
			// Configures new window
			aboutUsWindow.setBounds(50, 50, 400, 450);
			aboutUsWindow.getContentPane().setLayout(new BorderLayout());
			aboutUsWindow.setLayout(new BorderLayout());
				
			// Creates an editor pane
			JEditorPane aboutUsEditorPane;
				
			// URL of the HTML file
			URL url = Resources.getResource("aboutUs.html");
				
			try
			{
				// Try to load the aboutUs.html file in resources
				aboutUsEditorPane = new JEditorPane(url);
				
				// Setting the editor pane size to the HTML layout
				aboutUsEditorPane.setEditable(false);
				aboutUsEditorPane.setPreferredSize(new Dimension(400, 400));
				
				// Adds aboutUsEditorPane to aboutUsWindow
				aboutUsWindow.add(new JScrollPane(aboutUsEditorPane), BorderLayout.CENTER);
					
				// Creates a closeButton
				JButton closeButton = new JButton("Close");
				closeButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e)
					{
						aboutUsWindow.dispose();
					}
				});
					
				// Adds closeButton to aboutUsWindow
				aboutUsWindow.add(closeButton, BorderLayout.SOUTH);
					
				aboutUsWindow.setVisible(true);
			}
			catch (IOException ex)
			{
				// If loading fails, a JOptionPane appears
				JOptionPane.showMessageDialog(frame, "Could not read HTML file.", "Error reading HTML file", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}

//******************************************************************************
