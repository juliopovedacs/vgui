//******************************************************************************
// Copyright (C) 2016-2018 University of Oklahoma Board of Trustees.
//******************************************************************************
// Last modified: Tue Feb  9 20:33:16 2016 by Chris Weaver
//******************************************************************************
// Major Modification History:
//
// 20160209 [weaver]:	Original file (for CS 4053/5053 homeworks).
// 20180123 [weaver]:	Modified for use in CS 3053 team projects.
//
//******************************************************************************
// Notes:
//
//******************************************************************************

package edu.ou.cs.hci.stages;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

//******************************************************************************

/**
 * The <CODE>Stage1</CODE> class.<P>
 *
 * @author  Chris Weaver
 * @version %I%, %G%
 */
public final class Stage3
{
	//**********************************************************************
	// Public Class Members
	//**********************************************************************
	
	/**
	 * Scenarios names file location
	 */
	public static final String SCENARIOS_TITLES_FILE = "resources/scenarios/titles.txt";
	
	/**
	 * Scenarios descriptions file location
	 */
	public static final String SCENARIOS_DESCRIPTIONS_FILE = "resources/scenarios/descriptions.txt";
	
	/**
	 * Question 1 instructions
	 */
	public static final String QUESTION_1 = "What information about a video game would you consider relevant to decide to play it?";
	
	/**
	 * Question 2 instructions
	 */
	public static final String QUESTION_2 = "How many hours per week do you spend playing video games?";

	/**
	 * Question 3 instructions
	 */
	public static final String QUESTION_3 = "A newsfeed in a video games website is useful to be up to date with new releases, participate in social events and choose better video games.";

	/**
	 * Question 4 instructions
	 */
	public static final String QUESTION_4 = "How much time do you spend navigating the Internet using your mobile phone per day?";

	/**
	 * Question 5 instructions
	 */
	public static final String QUESTION_5 = "What is the mean you use the most to get informed about video games and why?";
	
	/**
	 * Submit
	 */
	public static final String SUBMIT = "Submit";

	/**
	 * Scenarios titles ArrayList
	 */
	public static ArrayList<String> scenariosTitles;
	
	/**
	 * Scenarios descriptions ArrayList
	 */
	public static ArrayList<String> scenariosDescriptions;
	
	//**********************************************************************
	// Private Members
	//**********************************************************************

	
	
	//**********************************************************************
	// Main
	//**********************************************************************

	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args)
	{
		// Main frame
		
		// Create Main Frame
		JFrame frame = new JFrame("Stage 3");
		
		// Creates GamesDisplayPanel and UserDisplayPanel
		JPanel centerMainPanel = new GamesDisplayPanel();
		JPanel leftUserPanel = new UserDisplayPanel();

		// Sets Main Frame´s bounds and layout
		frame.setBounds(50, 50, 600, 600);
		frame.getContentPane().setLayout(new BorderLayout());
		
		// Adds GamesDisplayPanel and UserDisplayPanel to Main Frame
		frame.getContentPane().add(centerMainPanel, BorderLayout.CENTER);
		frame.getContentPane().add(leftUserPanel, BorderLayout.WEST);
			
		//frame.setVisible(true);
		//frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		//frame.addWindowListener(new WindowAdapter() {public void windowClosing(WindowEvent e) {System.exit(0);}});
		
		
		// Personas and Scenarios Frame
		
		// Create Scenarios Frame
		JFrame scenariosFrame = new JFrame("Scenarios");
		
		// Scenarios Panel
		JPanel scenariosPanel = new ScenariosPanel();
		
		// Scenarios Frame settings
		scenariosFrame.setBounds(50, 50, 700, 300);
		scenariosFrame.getContentPane().setLayout(new BorderLayout());
		
		// Scenarios Panel added to Scenarios Frame
		scenariosFrame.getContentPane().add(scenariosPanel, BorderLayout.CENTER);
		
		//scenariosFrame.setVisible(true);
		//scenariosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		
		// Survey & Analysis Frame
		
		// Create survey Frame
		JFrame surveyFrame = new JFrame("Survey");
				
		// Questionnaire Panel
		JPanel questionnairePanel = new QuestionnairePanel();
				
		// Survey Frame settings
		surveyFrame.setBounds(50, 50, 1000, 800);
		surveyFrame.getContentPane().setLayout(new BorderLayout());
				
		// Questionnaire Panel added to Survey Frame
		surveyFrame.getContentPane().add(questionnairePanel, BorderLayout.CENTER);
				
		surveyFrame.setVisible(true);
		surveyFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}

	//**********************************************************************
	// Private Inner Classes
	//**********************************************************************
	
	/**
	 * SearchSortPanel
	 */
	private static final class SearchSortPanel extends JPanel
	{
		/**
		 * SearchSortPanel constructor
		 */
		public SearchSortPanel()
		{
			// Creates search field
			JTextField searchField = new JTextField("Search", 16);
			
			// Creates String array of sort by options
			String[] sortByOptions = {
				"Sort By:",
				"Title (A-Z)",
				"Title (Z-A)",
				"Platform",
				"Release Date"
			};
			
			// Creates a  combo box
			JComboBox sortByBox = new JComboBox(sortByOptions);
			
			// Sets layout
			setLayout(new BorderLayout());
			
			// Adds search text field and sort by combo box
			add(searchField, BorderLayout.WEST);
			add(sortByBox, BorderLayout.EAST);
		}
	}

	/**
	 * GamesDisplayPanel
	 */
	private static final class GamesDisplayPanel extends JPanel
	{
		/**
		 * GamesDisplayPanel constructor
		 */
		public GamesDisplayPanel()
		{
			// Creates SearchSortPanel
			JPanel 	searchSortPanel = new SearchSortPanel();
			
			// Sets layout
			setLayout(new BorderLayout());
			
			// Creates display panel
			JPanel display = new JPanel();
			display.setLayout(new GridLayout(12,3));
			
			// Adds games
			for (int i = 0; i < 12; i++) 
			{
				for (int j = 0; j < 3; j++) 
				{
					JButton btn = new JButton("Game " + i + j);
					btn.setPreferredSize(new Dimension(100, 100));
					display.add(btn);
				}
			}
			
			// Adds scroll pane
			JScrollPane scrollPane = new JScrollPane(display, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			
			// Adds searchSortPanel and scrollPane to GamesDisplayPanel
			add(searchSortPanel, BorderLayout.NORTH);
			add(scrollPane, BorderLayout.CENTER);
		}
	}
	
	/**
	 * UserDisplayPanel
	 */
	private static final class UserDisplayPanel extends JPanel
	{
		/**
		 * UserDisplayPanel constructor
		 */
		public UserDisplayPanel() 
		{
			// Sets layout
			setLayout(new GridLayout(20, 1));
			
			// Adds UI elements
			add(new JLabel("User Profile"));
			add(new JButton("Home"));
			add(new JButton("Featured Games"));
			add(new JButton("News and Events"));
			add(new JButton("My Games"));
			add(new JButton("My Favorites"));
			add(new JButton("My Wishlist"));
			add(new JButton("Recently Played"));
			add(new JButton("Most Played"));
			add(new JButton("Least Played"));
			add(new JButton("Never Played"));
			add(new JButton("Shuffle"));
		}
	}
	
	/**
	 * Scenarios Panel
	 */
	private static final class ScenariosPanel extends JPanel
	{
		/**
		 * ScenariosPanel constructor
		 */
		public ScenariosPanel()
		{
			// Sets panel layout
			setLayout(new BorderLayout());
						
			// Creates an instance of resources
			Resources resources = new Resources();
			
			// Initializes ArrayList that will store scenarios titles
			scenariosTitles = new ArrayList<>();
			
			// InitializesArrayList that will store scenarios descriptions
			scenariosDescriptions = new ArrayList<>();
			
			// Variable that will determine if files were read
			boolean filesRead = false;
			
			try
			{
				// Read Scenarios titles
				scenariosTitles = resources.getLines(SCENARIOS_TITLES_FILE);
				
				// Read Scenarios descriptions
				scenariosDescriptions = resources.getLines(SCENARIOS_DESCRIPTIONS_FILE);
				
				filesRead = true;
			}
			catch (Exception e)
			{
				// Error reading the files
				add(new JLabel("Mm, it seems as if there is an error reading your files. Are they written properly?"), BorderLayout.NORTH);
			}
			
			if(filesRead)
			{
				// Files were read
				
				if(scenariosTitles.size() > 0)
				{
					// There are scenarios
					
					// Model that will have the list´s data
					DefaultListModel<String> listModel = new DefaultListModel<>();
					
					// For every row in the SCENARIOS_NAMES_FILE add an element to the model
					for(int i = 0; i < scenariosTitles.size(); i++)
					{
						listModel.addElement(scenariosTitles.get(i));
					}
								
					// Creates scenarios list
					JList<String> scenariosList = new JList<>(listModel);
					
					// Single-selection JList of scenario titles
					scenariosList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
								
					// Creates scenarios descriptions text area
					JTextArea scenariosDescriptionsTextArea = new JTextArea();
					
					// Non-editable text area
					scenariosDescriptionsTextArea.setEditable(false);
					scenariosDescriptionsTextArea.setLineWrap(true);
					scenariosDescriptionsTextArea.setWrapStyleWord(true);
					
					// Creates a ListSelectionListener to update text area when a different scenario is selected
					scenariosList.addListSelectionListener(new ListSelectionListener() {
						public void valueChanged(ListSelectionEvent e)
						{
							int scenarioIndex = scenariosList.getSelectedIndex();
							scenariosDescriptionsTextArea.setText(scenariosDescriptions.get(scenarioIndex));
						}
					});
					
					// The first scenario is selected when the app starts
					scenariosList.setSelectedIndex(0);
						
					// Adds an instructions label to the panel
					add(new JLabel("Hi, to see a scenario description, click on a title:"), BorderLayout.NORTH);
					
					// Adds the scenarios list to the panel
					add(scenariosList, BorderLayout.WEST);
					
					// Adds the scenarios descriptions text area to the panel
					add(scenariosDescriptionsTextArea, BorderLayout.CENTER);
					
					// Adds a footer label to the panel
					add(new JLabel("By CGL"), BorderLayout.SOUTH);
				}
				else
				{
					// There are no scenarios
					
					// Adds an informative text to the panel
					add(new JLabel("Hi! There are no scenarios. What could have happened with them?"), BorderLayout.NORTH);
				}
			}
		}
	}
	
	/**
	 * Questionnaire Panel
	 */
	private static final class QuestionnairePanel extends JPanel implements ActionListener
	{
		//---------------------------------------------
		// GUI Attributes
		//---------------------------------------------
		
		/**
		 * Question 1 panel
		 */
		private JPanel question1Panel;
		
		/**
		 * Question 2 panel
		 */
		private JPanel question2Panel;
		
		/**
		 * Question 3 panel
		 */
		private JPanel question3Panel;
		
		/**
		 * Question 4 panel
		 */
		private JPanel question4Panel;
		
		/**
		 * Question 5 panel
		 */
		private JPanel question5Panel;
		
		//---------------------------------------------
		// Constructors
		//---------------------------------------------
		
		/**
		 * QuestionnairePanel constructor
		 */
		public QuestionnairePanel()
		{
			// Sets panel layout
			setLayout(new GridLayout(6, 1));
			
			question1Panel = new Question1Panel();
			question2Panel = new Question2Panel();
			question3Panel = new Question3Panel();
			question4Panel = new Question4Panel();
			question5Panel = new Question5Panel();
			
			add(question1Panel);
			add(question2Panel);
			add(question3Panel);
			add(question4Panel);
			add(question5Panel);
			
			//JPanel buttonPanel = new JPanel();
			//buttonPanel.setPreferredSize(new Dimension(1000, 20));
			
			JButton submitButton = new JButton("Submit");
			submitButton.setActionCommand(SUBMIT);
			submitButton.addActionListener(this);
			//buttonPanel.add(submitButton);
			
			add(submitButton);
		}
		
		//---------------------------------------------
		// Methods
		//---------------------------------------------
		
		public void actionPerformed(ActionEvent e)
		{
			if(e.getActionCommand() == SUBMIT)
			{
				System.out.println("Submit");
				
				//---------------------------------------------
				// Question 1
				//---------------------------------------------
				
				System.out.println("Question 1 answers:");
				
				// Asks Question1Panel for its answers
				ArrayList<String> question1Answers = ((Question1Panel) question1Panel).getSelectedItems();
				
				// Prints question 1 answers
				for(int i = 0; i < question1Answers.size(); i++)
				{
					System.out.println(question1Answers.get(i));
				}
				
				//---------------------------------------------
				// Question 2
				//---------------------------------------------
				
				System.out.println("Question 2 answer:");
				
				// Asks Question2Panel for the answer
				String question2Answer = ((Question2Panel) question2Panel).getSelectedAnswer();
				
				System.out.println(question2Answer);
				
				//---------------------------------------------
				// Question 3
				//---------------------------------------------
				
				System.out.println("Question 3 answer:");
				
				// Asks Question3Panel for the answer
				int question3Answer = ((Question3Panel) question3Panel).getSelectedAnswer();
				
				String question3AnswerStr = "";
				
				if (question3Answer == 0)
				{
					question3AnswerStr = "Strongly disagree";
				}
				else if (question3Answer == 1)
				{
					question3AnswerStr = "Disagree";
				}
				else if (question3Answer == 2)
				{
					question3AnswerStr = "Neutral";
				}
				else if (question3Answer == 3)
				{
					question3AnswerStr = "Agreee";
				}
				else
				{
					question3AnswerStr = "Strongly agree";
				}
				
				System.out.println(question3AnswerStr);
				
				//---------------------------------------------
				// Question 4
				//---------------------------------------------
				
				System.out.println("Question 4 answer:");
				
				// Asks Question4Panel for the answer
				String question4Answer = ((Question4Panel) question4Panel).getSelectedAnswer();
				
				System.out.println(question4Answer);
				
				//---------------------------------------------
				// Question 5
				//---------------------------------------------
				
				System.out.println("Question 5 answer:");
				
				String question5Answer = ((Question5Panel) question5Panel).getAnswer();
				
				System.out.println(question5Answer);
			}
		}
	}
	
	/**
	 * Question 1 Panel
	 */
	private static final class Question1Panel extends JPanel
	{
		//---------------------------------------------
		// GUI Attributes
		//---------------------------------------------
		
		/**
		 * Check box 1
		 */
		private JCheckBox cb1;
		
		/**
		 * Check box 2
		 */
		private JCheckBox cb2;
		
		/**
		 * Check box 3
		 */
		private JCheckBox cb3;
		
		/**
		 * Check box 4
		 */
		private JCheckBox cb4;
		
		/**
		 * Check box 5
		 */
		private JCheckBox cb5;
		
		//---------------------------------------------
		// Constructors
		//---------------------------------------------
		
		/**
		 * Question1Panel constructor
		 */
		public Question1Panel()
		{
			// Sets panel layout
			setLayout(new GridLayout(6, 1));
			
			// Sets a titled border for the panel
			TitledBorder border = new TitledBorder("Question 1");
			border.setTitleColor(Color.BLUE);
			this.setBorder(border);
			
			// Creates a label with instructions
			JLabel instructions = new JLabel(QUESTION_1);
			
			// Adds instructions to the panel
			add(instructions);
			
			// Creates 5 check boxes
			cb1 = new JCheckBox("Title");
			cb2 = new JCheckBox("Rating");
			cb3 = new JCheckBox("Reviews");
			cb4 = new JCheckBox("Category");
			cb5 = new JCheckBox("Price");
			
			// Adds the check boxes to the panel
			add(cb1);
			add(cb2);
			add(cb3);
			add(cb4);
			add(cb5);
		}
		
		//---------------------------------------------
		// Methods
		//---------------------------------------------
		
		/**
		 * Returns selected items for question 1
		 * @return selectedItems
		 */
		public ArrayList<String> getSelectedItems()
		{
			ArrayList<String> selectedItems = new ArrayList<String>();
			
			if (cb1.isSelected() == true)
			{
				selectedItems.add(cb1.getText());
			}
			if (cb2.isSelected() == true)
			{
				selectedItems.add(cb2.getText());
			}
			if (cb3.isSelected() == true)
			{
				selectedItems.add(cb3.getText());
			}
			if (cb4.isSelected() == true)
			{
				selectedItems.add(cb4.getText());
			}
			if (cb5.isSelected() == true)
			{
				selectedItems.add(cb5.getText());
			}
			
			return selectedItems;
		}
	}
	
	/**
	 * Question 2 Panel
	 */
	private static final class Question2Panel extends JPanel
	{
		//---------------------------------------------
		// GUI Attributes
		//---------------------------------------------
		
		/**
		 * Spinner
		 */
		private JSpinner spinner;
		
		//---------------------------------------------
		// Constructors
		//---------------------------------------------
		
		/**
		 * Question2Panel constructor
		 */
		public Question2Panel()
		{
			// Sets panel layout
			setLayout(new GridLayout(2, 1));
			
			// Sets a titled border for the panel
			TitledBorder border = new TitledBorder("Question 2");
			border.setTitleColor(Color.BLUE);
			this.setBorder(border);
			
			// Creates a label with instructions
			JLabel instructions = new JLabel(QUESTION_2);
			
			// Adds instructions to the panel
			add(instructions);
			
			// Creates an array of strings
			String[] numbers = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
			
			// Creates a spinner model
			SpinnerListModel spinnerModel = new SpinnerListModel(numbers);
			
			// Initializes spinner
			spinner = new JSpinner(spinnerModel);
			
			// Adds the spinner to the panel
			add(spinner);
		}
		
		//---------------------------------------------
		// Methods
		//---------------------------------------------
		
		/**
		 * Returns selected answer
		 * @return spinner.getValue()
		 */
		public String getSelectedAnswer()
		{
			String answer = (String) spinner.getValue();
			
			return answer;
		}
	}
	
	/**
	 * Question 3 Panel
	 */
	private static final class Question3Panel extends JPanel
	{
		//---------------------------------------------
		// GUI Attributes
		//---------------------------------------------
		
		/**
		 * Slider
		 */
		private JSlider slider;
		
		//---------------------------------------------
		// Constructors
		//---------------------------------------------
		
		/**
		 * Question3Panel constructor
		 */
		public Question3Panel()
		{
			// Sets panel layout
			setLayout(new GridLayout(2, 1));
			
			// Sets a titled border for the panel
			TitledBorder border = new TitledBorder("Question 3");
			border.setTitleColor(Color.BLUE);
			this.setBorder(border);
			
			// Creates a label with instructions
			JLabel instructions = new JLabel(QUESTION_3);
			
			// Adds instructions to the panel
			add(instructions);
			
			// Initiates and configures a slider
			slider = new JSlider(JSlider.HORIZONTAL, 0, 4, 2);
			slider.setMinorTickSpacing(2);
		    slider.setMajorTickSpacing(10);
		    slider.setPaintTicks(true);
		    slider.setPaintLabels(true);
		    		    
		    // Creates a Hash table and puts inside it 5 labels
		    Hashtable<Integer, JLabel> map = new Hashtable<Integer, JLabel>();
		    map.put(0, new JLabel("Strongly disagree"));
		    map.put(1, new JLabel("Disagree"));
		    map.put(2, new JLabel("Neutral"));
		    map.put(3, new JLabel("Agree"));
		    map.put(4, new JLabel("Strongly agree"));
		    
		    // Maps JSlider´s integers into text labels
		    slider.setLabelTable(map);
			
			// Adds slider to the panel
		    add(slider);
		}
		
		//---------------------------------------------
		// Methods
		//---------------------------------------------
		
		/**
		 * Returns selected answer
		 * @return slider.getValue()
		 */
		public int getSelectedAnswer()
		{
			int answer = slider.getValue();
			
			return answer;
		}
	}
	
	/**
	 * Question 4 Panel
	 */
	private static final class Question4Panel extends JPanel
	{
		//---------------------------------------------
		// GUI Attributes
		//---------------------------------------------
		
		/**
		 * First range radio button
		 */
		private JRadioButton firstRange;
		
		/**
		 * Second range radio button
		 */
		private JRadioButton secondRange;
		
		/**
		 * Third range radio button
		 */
		private JRadioButton thirdRange;
		
		/**
		 * Fourth range radio button
		 */
		private JRadioButton fourthRange;
		
		//---------------------------------------------
		// Constructor
		//---------------------------------------------
		
		/**
		 * Question4Panel constructor
		 */
		public Question4Panel()
		{
			// Sets panel layout
			setLayout(new GridLayout(5, 1));
			
			// Sets a titled border for the panel
			TitledBorder border = new TitledBorder("Question 4");
			border.setTitleColor(Color.BLUE);
			this.setBorder(border);
			
			// Creates a label with instructions
			JLabel instructions = new JLabel(QUESTION_4);
			
			// Adds instructions to the panel
			add(instructions);
			
			// Initializes 4 radio buttons
			firstRange = new JRadioButton("Less than 2 hours");
			secondRange = new JRadioButton("2 - 4 hours");
			thirdRange = new JRadioButton("5 - 6 hours");
			fourthRange = new JRadioButton("More than 6 hours");
			
			// Creates ButtonGroup to logically group button groups (mutually exclusive options)
			ButtonGroup radioButtonsGroup = new ButtonGroup();
			radioButtonsGroup.add(firstRange);
			radioButtonsGroup.add(secondRange);
			radioButtonsGroup.add(thirdRange);
			radioButtonsGroup.add(fourthRange);
			
			// Adds buttons groups to the panel
			add(firstRange);
			add(secondRange);
			add(thirdRange);
			add(fourthRange);
		}
		
		//---------------------------------------------
		// Methods
		//---------------------------------------------
		
		/**
		 * Returns selected answer
		 * @return answer
		 */
		public String getSelectedAnswer()
		{
			String answer = "";
			
			if (firstRange.isSelected() == true)
			{
				answer = firstRange.getText();
			}
			else if (secondRange.isSelected() == true)
			{
				answer = secondRange.getText();
			}
			else if (thirdRange.isSelected() == true)
			{
				answer = thirdRange.getText();
			}
			else if (fourthRange.isSelected() == true)
			{
				answer = fourthRange.getText();
			}
			else
			{
				answer = "The user did not select an answer";
			}
			
			return answer;
		}
	}
	
	/**
	 * Question 5 Panel
	 */
	private static final class Question5Panel extends JPanel
	{
		//---------------------------------------------
		// GUI Attributes
		//---------------------------------------------
		
		/**
		 * Text area
		 */
		private JTextArea textArea;
		
		//---------------------------------------------
		// Constructors
		//---------------------------------------------
		
		/**
		 * Question1Panel constructor
		 */
		public Question5Panel()
		{
			// Sets panel layout
			setLayout(new GridLayout(2, 1));
			
			// Sets a titled border for the panel
			TitledBorder border = new TitledBorder("Question 5");
			border.setTitleColor(Color.BLUE);
			this.setBorder(border);
			
			// Creates a label with instructions
			JLabel instructions = new JLabel(QUESTION_5);
			
			// Adds instructions to the panel
			add(instructions);
			
			// Initializes text area and adds vertical scroll bar
			textArea = new JTextArea(30, 20);
			JScrollPane scrollingArea = new JScrollPane(textArea);
		    scrollingArea.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			
			// Adds the text area with the scroll bar to the panel
		    add(scrollingArea);
		}
		
		//---------------------------------------------
		// Methods
		//---------------------------------------------
		
		/**
		 * Returns answer written by the user
		 * @return answer
		 */
		public String getAnswer()
		{
			String answer = textArea.getText();
			
			return answer;
		}
	}
}

//******************************************************************************
